/* Package-owned music segment. CRS remains responsible for output routing/gain. */
(function(root){
 'use strict';
 function time(value){
  const text=String(value??'').trim();
  if(/^[0-9]{1,4}$/.test(text))return Math.min(3600,Number(text));
  const m=text.match(/^([0-9]{1,3}):([0-5][0-9])$/);
  return m?Math.min(3600,Number(m[1])*60+Number(m[2])):0;
 }
 function fade(value){const n=Number(value);return Number.isFinite(n)?Math.max(0,Math.min(30,n)):0;}
 function create(audio,clock={now:()=>performance.now(),frame:f=>requestAnimationFrame(f),cancelFrame:id=>cancelAnimationFrame(id),timer:(f,ms)=>setTimeout(f,ms),cancelTimer:id=>clearTimeout(id)}){
  let generation=0,cycle=0,disposed=false,listeners=[],preparation=[],delayTimer=0,boundaryTimer=0,prepareTimer=0,frame=0;
  let options={},endpoint=0,segmentLength=0,preparing=false,active=false,firstCycle=true;
  function gain(n){audio.volume=Math.max(0,Math.min(1,n));}
  function clearPreparation(){
   clock.cancelTimer(prepareTimer);prepareTimer=0;
   for(const [name,fn] of preparation)audio.removeEventListener(name,fn);
   preparation=[];preparing=false;
  }
  function cancelBoundary(){clock.cancelTimer(boundaryTimer);boundaryTimer=0;clock.cancelFrame(frame);frame=0;}
  function stop(){
   generation++;cycle++;active=false;clearPreparation();cancelBoundary();
   clock.cancelTimer(delayTimer);delayTimer=0;
   for(const [name,fn] of listeners)audio.removeEventListener(name,fn);
   listeners=[];audio.pause();
  }
  function start(controls){
   if(disposed)return;
   stop();const token=generation;
   options={offset:time(controls.music_start_offset),length:time(controls.music_play_length),
    fadeIn:fade(controls.music_fade_in_seconds),fadeOut:fade(controls.music_fade_out_seconds),loop:controls.music_loop!==false};
   const source=typeof controls.music==='string'?controls.music.trim():'';
   audio.loop=false;firstCycle=true;gain(1);
   if(!source){audio.removeAttribute('src');audio.load();return;}
   if(audio.getAttribute('src')!==source){audio.src=source;audio.load();}
   function valid(){return !disposed&&token===generation;}
   function listen(name,fn){const guarded=()=>{if(valid())fn();};listeners.push([name,guarded]);audio.addEventListener(name,guarded);}
   function finish(){
    if(!active||preparing||!valid())return;
    active=false;cancelBoundary();audio.pause();gain(0);
    if(options.loop)beginCycle(false);
   }
   function update(){
    if(!valid()||!active||preparing)return;
    cancelBoundary();
    const position=Number(audio.currentTime);
    if(!Number.isFinite(position))return;
    const remaining=endpoint-position;
    if(remaining<=0){finish();return;}
    const elapsed=Math.max(0,position-options.offset);
    // Envelope follows actual audio position, so buffering cannot consume a fade.
    const fadeIn=Math.min(options.fadeIn,segmentLength),fadeOut=Math.min(options.fadeOut,segmentLength);
    const opening=firstCycle&&fadeIn>0?Math.min(1,elapsed/fadeIn):1;
    const closing=fadeOut>0?Math.min(1,remaining/fadeOut):1;
    gain(Math.min(opening,closing));
    if(audio.paused||audio.seeking)return;
    const rate=Number(audio.playbackRate)>0?Number(audio.playbackRate):1;
    const c=cycle;
    if(opening<1||(fadeOut>0&&remaining<=fadeOut+.001)){frame=clock.frame(()=>{if(valid()&&c===cycle){frame=0;update();}});}
    else {
     const wait=Math.max(.05,remaining-fadeOut)/rate;
     boundaryTimer=clock.timer(()=>{if(valid()&&c===cycle){boundaryTimer=0;update();}},wait*1000);
    }
   }
   function beginCycle(first){
    if(!valid())return;
    clearPreparation();cancelBoundary();audio.pause();active=false;preparing=true;firstCycle=first;
    gain(first&&options.fadeIn>0?0:1);
    const c=++cycle;
    function current(){return valid()&&c===cycle&&preparing;}
    function prepListen(name,fn){preparation.push([name,fn]);audio.addEventListener(name,fn);}
    function ready(){
     if(!current())return;
     clearPreparation();active=true;
     // A stale seek/play promise must never affect a newer cycle or selection.
     try{
      const result=audio.play();
      if(result&&typeof result.catch==='function')result.catch(()=>{
       if(valid()&&c===cycle){active=false;cancelBoundary();}
      });
     }catch(_error){active=false;cancelBoundary();}
    }
    let metadataSeen=false;
    function metadata(){
     if(!current()||metadataSeen)return;
     const duration=Number(audio.duration);
     if(!Number.isFinite(duration)||duration<=0)return;
     metadataSeen=true;endpoint=options.length>0?Math.min(duration,options.offset+options.length):duration;
     segmentLength=endpoint-options.offset;
     if(segmentLength<=0){clearPreparation();gain(0);return;}
     function seeked(){if(current()&&!audio.seeking&&Math.abs(Number(audio.currentTime)-options.offset)<.05)ready();}
     prepListen('seeked',seeked);
     try{audio.currentTime=options.offset;}catch(_error){clearPreparation();gain(0);return;}
     seeked();
    }
    prepListen('loadedmetadata',metadata);prepListen('durationchange',metadata);
    prepareTimer=clock.timer(()=>{if(current()){clearPreparation();gain(0);}},10000);
    if(audio.readyState>=1)metadata();
   }
   listen('playing',update);listen('timeupdate',update);listen('ratechange',update);
   listen('pause',cancelBoundary);listen('waiting',cancelBoundary);
   listen('ended',finish);
   listen('error',()=>{active=false;clearPreparation();cancelBoundary();clock.cancelTimer(delayTimer);delayTimer=0;gain(0);});
   const delay=time(controls.music_delay_time);
   if(delay)delayTimer=clock.timer(()=>{if(valid()){delayTimer=0;beginCycle(true);}},delay*1000);
   else beginCycle(true);
  }
  function dispose(){if(disposed)return;stop();disposed=true;}
  return {start,stop,dispose};
 }
 const api={create,time};if(typeof module==='object'&&module.exports)module.exports=api;else root.CRSSegmentMusic=api;
})(typeof window==='undefined'?globalThis:window);
