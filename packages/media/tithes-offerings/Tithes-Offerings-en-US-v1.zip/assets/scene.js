(() => {
  "use strict";
  const $ = (id) => document.getElementById(id);
  const design = $("design");
  const defaults = {
    layout_style: "Cards", show_method_icons: true, page_theme: "html:crimson_gold",
    logo_source: "Church Identity", logo_side: "Left", logo_override: "",
    animate: true, entrance_speed: 1, marquee_speed: 1, music: "",
    brand_line: "", eyebrow: "", heading: "", introduction: "", gratitude: "", indent_closing: true,
    methods: [{ method_kind: "Online", method_title: "", method_value: "", method_note: "", enabled: true }],
    show_ticker: true, ticker_messages: "",
    end_marker: "✦", show_start_marker: false, divider_marker: "•"
  };
  function value(controls, key) {
    return Object.prototype.hasOwnProperty.call(controls, key) ? controls[key] : defaults[key];
  }
  function fitDesign() {
    const viewport = $("viewport");
    const scale = Math.min(viewport.clientWidth / 1920, viewport.clientHeight / 1080);
    design.style.transform = `scale(${Number.isFinite(scale) && scale > 0 ? scale : 1})`;
  }
  function renderDetails(element, raw) {
    const text = String(raw ?? "");
    const qrPattern = /(data:image\/svg\+xml;base64,[A-Za-z0-9+/=]+)/g;
    let start = 0;
    for (const match of text.matchAll(qrPattern)) {
      if (match.index > start) element.append(document.createTextNode(text.slice(start, match.index)));
      const img = document.createElement("img");
      img.className = "inline-qr";
      img.alt = "Giving link QR code";
      img.src = match[0];
      element.append(img);
      start = match.index + match[0].length;
    }
    if (start < text.length) element.append(document.createTextNode(text.slice(start)));
  }
  function appendInline(parent, raw) {
    const text = String(raw ?? "");
    let plain = "";
    function flush() {
      if (plain) parent.append(document.createTextNode(plain));
      plain = "";
    }
    for (let index = 0; index < text.length;) {
      if (text[index] === "\\" && /[\\#*.-]/.test(text[index + 1] || "")) {
        plain += text[index + 1];
        index += 2;
        continue;
      }
      if (text[index] === "*" && text[index + 1] !== " ") {
        const count = text.startsWith("***", index) ? 3 : text.startsWith("**", index) ? 2 : 1;
        const delimiter = "*".repeat(count);
        let end = text.indexOf(delimiter, index + count);
        while (end > 0 && text[end - 1] === "\\") end = text.indexOf(delimiter, end + count);
        if (end > index + count) {
          flush();
          const outer = document.createElement(count === 1 ? "em" : "strong");
          const inner = count === 3 ? document.createElement("em") : outer;
          if (count === 3) outer.append(inner);
          appendInline(inner, text.slice(index + count, end));
          parent.append(outer);
          index = end + count;
          continue;
        }
      }
      plain += text[index];
      index += 1;
    }
    flush();
  }
  function renderMarkdown(element, raw) {
    element.replaceChildren();
    let paragraph = null;
    let list = null;
    for (const line of String(raw ?? "").split(/\r?\n/)) {
      if (!line.trim()) { paragraph = null; list = null; continue; }
      const heading = line.match(/^(#{1,3})\s+(.+)$/);
      const bullet = line.match(/^[-*]\s+(.+)$/);
      const numbered = line.match(/^\d+\.\s+(.+)$/);
      if (heading) {
        paragraph = null; list = null;
        const h = document.createElement(`h${Math.min(heading[1].length + 2, 5)}`);
        appendInline(h, heading[2]);
        element.append(h);
      } else if (bullet || numbered) {
        paragraph = null;
        const kind = bullet ? "ul" : "ol";
        if (!list || list.tagName.toLowerCase() !== kind) {
          list = document.createElement(kind);
          element.append(list);
        }
        const item = document.createElement("li");
        appendInline(item, (bullet || numbered)[1]);
        list.append(item);
      } else {
        list = null;
        if (!paragraph) {
          paragraph = document.createElement("p");
          element.append(paragraph);
        } else paragraph.append(document.createElement("br"));
        appendInline(paragraph, line);
      }
    }
  }
  function methodIcon(kind) {
    const shapes = {
      "Online": "M10 13a5 5 0 0 0 7.07 0l3-3A5 5 0 0 0 13 2.93l-1.7 1.7 M14 11a5 5 0 0 0-7.07 0l-3 3A5 5 0 0 0 11 21.07l1.7-1.7",
      "Text": "M7 2h10a2 2 0 0 1 2 2v16a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2z M10 18h4",
      "Mail": "M4 6h16v12H4z M4 7l8 6 8-6",
      "In Person": "M12 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8z M4 21a8 8 0 0 1 16 0",
      "Other": "M5 12h.01 M12 12h.01 M19 12h.01"
    };
    const wrapper = document.createElement("span");
    wrapper.className = "method-icon";
    wrapper.setAttribute("role", "img");
    wrapper.setAttribute("aria-label", kind);
    const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    svg.setAttribute("viewBox", "0 0 24 24");
    svg.setAttribute("aria-hidden", "true");
    const path = document.createElementNS("http://www.w3.org/2000/svg", "path");
    path.setAttribute("d", shapes[kind] || shapes.Other);
    svg.append(path);
    wrapper.append(svg);
    return wrapper;
  }
  function renderMethods(rows, layout, showIcons) {
    const methods = $("methods");
    methods.replaceChildren();
    const visible = Array.isArray(rows)
      ? rows.filter((row) => row && typeof row === "object" && row.enabled !== false)
      : [];
    const cap = layout === "Tiles" ? 3 : 4;
    // CRS validates the dynamic cap before Bake. Preview keeps excess rows visible.
    for (const row of visible.slice(0, 4)) {
      const card = document.createElement("article");
      card.className = "method";
      const title = document.createElement("h2");
      title.textContent = String(row.method_title ?? "");
      title.hidden = !title.textContent.trim();
      const detail = document.createElement("p");
      detail.className = "method-value";
      renderDetails(detail, row.method_value);
      const note = document.createElement("p");
      note.className = "method-note";
      note.textContent = String(row.method_note ?? "");
      note.hidden = !note.textContent.trim();
      if (showIcons) card.append(methodIcon(String(row.method_kind ?? "Online")));
      card.append(title, detail, note);
      methods.append(card);
    }
    methods.classList.toggle("over-limit", visible.length > cap);
  }
  function renderTicker(controls, uses) {
    const track = $("tickerTrack");
    track.replaceChildren();
    // Image references resolve before reaching the package. Remove known
    // logo URLs and inline image data while retaining other text on the line.
    const imageSources = [uses["church.logo"], value(controls, "logo_override")]
      .filter((source) => typeof source === "string" && source.trim())
      .sort((a, b) => b.length - a.length);
    const lines = String(value(controls, "ticker_messages") ?? "")
      .split(/\r?\n/)
      .map((line) => {
        for (const source of imageSources) line = line.split(source).join("");
        return line.replace(/data:image\/[a-z0-9.+-]+;base64,[a-z0-9+/=]+/gi, "").trim();
      })
      .filter(Boolean);
    const ticker = $("ticker");
    ticker.hidden = value(controls, "show_ticker") !== true || lines.length === 0;
    if (ticker.hidden) return;
    const marker = String(value(controls, "end_marker"));
    const divider = String(value(controls, "divider_marker"));
    const lane = document.createElement("span");
    lane.className = "ticker-lane";
    track.append(lane);
    function appendSymbol(symbol, className) {
      if (symbol === "None") return;
      const separator = document.createElement("span");
      separator.className = className;
      separator.textContent = symbol;
      lane.append(separator);
    }
    function appendCycle() {
      if (value(controls, "show_start_marker") === true)
        appendSymbol(marker, "ticker-end-marker");
      for (let index = 0; index < lines.length; index++) {
        const line = lines[index];
        const item = document.createElement("span");
        item.className = "ticker-copy";
        item.textContent = line;
        lane.append(item);
        if (index < lines.length - 1)
          appendSymbol(divider, "ticker-divider");
      }
      appendSymbol(marker, "ticker-end-marker");
    }
    // Fill at least one viewport before duplicating the lane. Both lanes
    // have identical width, so moving by half the track loops seamlessly.
    appendCycle();
    for (let index = 0; index < 64 && lane.scrollWidth < ticker.clientWidth + 80; index++) {
      appendCycle();
    }
    track.append(lane.cloneNode(true));
  }
  function syncMusic(rawSource) {
    const music = document.getElementById("music");
    const source = typeof rawSource === "string" ? rawSource.trim() : "";
    if (!source) {
      music.pause();
      if (music.hasAttribute("src")) {
        music.removeAttribute("src");
        music.load();
      }
      return;
    }
    if (music.getAttribute("src") !== source) {
      music.pause();
      music.src = source;
      music.load();
    }
    if (music.paused) {
      const playback = music.play();
      if (playback && typeof playback.catch === "function") playback.catch(() => {});
    }
  }

  function applySceneState(state) {
    const controls = state && state.controls && typeof state.controls === "object"
      ? state.controls : defaults;
    const uses = state && state.resolved_uses && typeof state.resolved_uses === "object"
      ? state.resolved_uses : {};
    const layout = String(value(controls, "layout_style"));
    const cards = layout === "Cards";
    const right = value(controls, "logo_side") === "Right";
    const animate = value(controls, "animate") === true;
    const theme = String(value(controls, "page_theme"));
    design.className = ["design", cards ? "style-cream" : "style-navy",
      theme.startsWith("crs:") ? "theme-crs" : theme === "html:crimson_gold" ? "theme-crimson"
        : theme === "html:forest_cream" ? "theme-forest" : "theme-navy",
      right ? "logo-right" : "logo-left"].join(" ");
    const themeColors = {
      "--crs-primary": "theme.primary", "--crs-secondary": "theme.secondary",
      "--crs-accent": "theme.accent", "--crs-background": "theme.background",
      "--crs-card": "theme.card_background", "--crs-background-alt": "theme.background_alt",
      "--crs-text": "theme.text_primary",
      "--crs-muted": "theme.text_secondary"
    };
    for (const [property, key] of Object.entries(themeColors)) {
      const color = String(uses[key] ?? "");
      if (theme.startsWith("crs:") && /^#[0-9a-fA-F]{3,8}$/.test(color))
        design.style.setProperty(property, color);
      else design.style.removeProperty(property);
    }
    for (const [property, key] of [["--crs-font", "theme.font_family"],
                                    ["--crs-display-font", "theme.display_font_family"]]) {
      const font = String(uses[key] ?? "");
      if (theme.startsWith("crs:") && font && !/[;{}]/.test(font))
        design.style.setProperty(property, font);
      else design.style.removeProperty(property);
    }
    const entrance = Number(value(controls, "entrance_speed"));
    const marquee = Number(value(controls, "marquee_speed"));
    design.style.setProperty("--motion-duration", `${0.85 / (Number.isFinite(entrance) && entrance > 0 ? entrance : 1)}s`);
    design.style.setProperty("--marquee-duration", `${27 / (Number.isFinite(marquee) && marquee > 0 ? marquee : 1)}s`);
    for (const id of ["eyebrow", "heading"]) {
      $(id).textContent = String(value(controls, id) ?? "");
    }
    renderMarkdown($("introduction"), value(controls, "introduction"));
    renderMarkdown($("gratitude"), value(controls, "gratitude"));
    $("gratitude").classList.toggle("indent-paragraphs", value(controls, "indent_closing") === true);
    $("churchName").textContent = String(uses["church.name"] || "");
    const brandLine = String(value(controls, "brand_line") ?? "").trim();
    $("brandLine").textContent = brandLine;
    $("brandLine").hidden = !brandLine;
    const logoSource = String(value(controls, "logo_source"));
    const logo = String(logoSource === "Custom Image"
        ? (value(controls, "logo_override") || "")
        : (uses["church.logo"] || ""));
    $("brandLogo").src = logo;
    $("brandLogo").hidden = !logo;
    $("brandPlaceholder").hidden = Boolean(logo);
    renderMethods(value(controls, "methods"), layout, value(controls, "show_method_icons") === true);
    renderTicker(controls, uses);
    syncMusic(value(controls, "music"));
    // Start after the current logo and text are populated. Reapplying Draft
    // state also replays the entrance instead of retaining a finished rail.
    if (animate) {
      void design.offsetWidth;
      design.classList.add("animate");
    }
  }
  $("brandLogo").addEventListener("error", () => {
    $("brandLogo").hidden = true;
    $("brandPlaceholder").hidden = false;
  });
  window.addEventListener("resize", fitDesign);
  window.addEventListener("message", (event) => {
    const state = event.data;
    if (!state || state.type !== "chi-rho-scene-state" ||
        state.schema !== "chi-rho-studio.scene-state" || state.version !== 1) return;
    applySceneState(state);
  });
  applySceneState({ controls: defaults, resolved_uses: {} });
  fitDesign();
})();
