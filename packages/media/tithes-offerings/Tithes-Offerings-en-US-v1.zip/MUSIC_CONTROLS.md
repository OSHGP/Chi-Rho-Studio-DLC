# Prayer List and Tithes & Offerings music -- 1.0.3 trial

These two packages use the same tested segment-music.js bytes. They require the
accepted CRS_Scene_Audio_Controls.patch and a full CRS restart after that patch.
No additional CRS patch or security-policy exception is needed. Do not publish
the trial packages yet; eventual DLC publication goes through Admin.

Choose/Clear and the filename remain visible. Audio settings appear when a file
is chosen. Clearing audio hides the settings without discarding their values.
Newly chosen files show their original display name; old UUID names require
choosing the original file once. Managed playback URLs stay internal.

- Start Offset: seconds or mm:ss; default 00:00. Skips inside the song.
- Fade In: seconds; default 0.25. Zero disables. Applies only on the first play.
- Start Delay: seconds or mm:ss; default 00:00. Waits before the first play,
  independently of the offset; it does not count toward Play Length.
- Fade Out: seconds; default 0.25. Zero disables. Ends at the segment endpoint.
- Play Length: seconds or mm:ss; **00:00 plays to the end of the audio file**.
  A nonzero value is duration after Start Offset, not a timestamp in the song.
- Loop Audio: on by default. Repeats the selected segment from Start Offset.
  Opening delay and fade-in do not repeat. Fade-out occurs at each segment end;
  repeating begins again at normal gain, without another opening fade.

Example: offset 00:15 plus length 01:00 plays file 00:15 through 01:15. If the file
ends earlier, its end becomes the endpoint. Offset at/beyond the file end stays
silent. Both fades are bounded by the actual selected segment length; overlapping
fades use the quieter envelope. Fades follow audio position rather than elapsed
wall-clock time, so buffering does not run down the envelope ahead of the song.

This replaces Stop at End for these two packages. Their visuals have no imposed
new ending: Prayers may continue scrolling and Tithes may continue its ticker
when non-looping music ends. The last/current visual stays displayed and the
queue does not advance. Scroll-loop and ticker settings do not restart music.

Restart or reapplying Draft state starts a fresh audio sequence. Replacing the
source or closing the page cancels delayed playback, seeks, endpoint checks and
fades. Failed autoplay is not retried continuously. Loading/seek preparation is
bounded to ten seconds; Restart can try again. Existing CRS output volume, mute,
Presentation routing and enlarged-preview routing are unchanged.

## Verification still needed on the authoritative computer

1. Import the two inner ZIPs separately. Check controls, filename, Choose/Clear,
   Save, Prev/Next and reopen/restart persistence. Use whole seconds or mm:ss;
   decimal time input warns and keeps the last valid time. Fades allow decimals.
2. Offset 00:15, delay 00:03, length 00:10, fades 2 seconds, Loop Audio off:
   expect 3 seconds of silence, then file 00:15--00:25, fade to silence, visuals
   continuing. Test a short Prayer list and a long scrolling one; Tithes ticker
   and static page remain independent of the sound.
3. Enable Loop Audio: repeat file 00:15--00:25, with fade-out each time but no
   repeated three-second delay or opening fade-in. Toggle Prayer scroll looping
   and Tithes ticker settings; neither should define the audio endpoint.
4. Length 00:00 plays to file end. Try a length longer than the remaining song,
   offset past the end, zero fades and no chosen audio.
5. Restart during delay/fade/seek, close Enlarge/Details and change queued item.
   No late or doubled sound. Explicitly Re-Bake and compare Draft/Baked output,
   Presentation and OBS; keep Quick Volume/Mute and separate preview routing.

The user passed revised Announcements audio; these are new package integrations
and remain unaccepted until tested. Preserve existing Prayer/Tithes controls,
Church Identity/QR/Markdown, styling, scrolling, ticker and layout checks. These
packages do not include Announcements page turns or adaptive image color changes.
