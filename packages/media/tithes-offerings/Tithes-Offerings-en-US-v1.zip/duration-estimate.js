/* Optional CRS Settings feedback. No playback, audio or external resources. */
(() => {
  let request = null;
  let reporter = null;
  let last = "";
  function publish() {
    if (!request || !reporter) return;
    const value = reporter();
    if (!value || !["finite", "cycle", "open", "static"].includes(value.kind)
        || typeof value.seconds !== "number" || !Number.isFinite(value.seconds)
        || value.seconds < 0 || value.seconds > 86400) return;
    const key = JSON.stringify([request, value.kind, value.seconds]);
    if (key === last) return;
    last = key;
    parent.postMessage({type: "chi-rho-duration-estimate", request, ...value}, "*");
  }
  window.CRSDurationEstimate = {setReporter(fn) { reporter = fn; publish(); }, publish};
  window.addEventListener("message", event => {
    const value = event.data;
    if (event.source !== parent || !value || value.type !== "chi-rho-duration-request"
        || typeof value.request !== "string" || value.request.length > 64
        || !value.request || value.href !== location.href) return;
    request = value.request;
    publish();
  });
})();
