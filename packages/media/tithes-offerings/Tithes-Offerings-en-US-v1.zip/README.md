# Tithes & Offerings -- version 1.0.0 (en-US)

This is a downloadable CRS-aware HTML package and a structured giving-page example. **Cards** follows Smalltown and supports up to four giving methods. **Tiles** follows Anytown and supports up to three. The CRS Theme selector offers Crimson & Gold, Navy & Gold, and Forest & Cream HTML presets, along with the Host's CRS Themes. Logo Side and theme are independent of layout.

Import this ZIP as a Custom HTML item. Add your church content in Media Details, check Draft Preview, then Bake. Saved content is carried in Service Plans; the ZIP itself contains no church giving details.

Message, method, and footer text start empty. Placeholder hints do not appear in Draft Preview or Bake. Method Title, Displayed Details, Small Note, Introduction, Closing Message, and Footer Messages accept Church Identity references. For example, insert `{CID.LinkName.Giving.Donation}` in Method Title, `{CID.QR.Giving.Donation}` in Displayed Details, and `{CID.Link.Giving.Donation}` in Small Note after saving a Giving link named Donation in Church Identity. A QR data URL resolves to an inline image in Displayed Details. Invalid references remain visible in Draft Preview with a red outline around the field and prevent Bake.

The demo label beneath the church name has been removed. **Brand Line** is optional and starts blank. Enter a short custom line, or insert `{CID.Saying}` to use the current Host Church Saying; an empty line is hidden. Bake freezes the resolved saying for Guest playback.

The stray decorative strips at the top of the Cards composition have been removed. **Method Kind** remains an editor choice used to select an icon, but the kind name is not printed on the HTML. **Show Method Icons** defaults on and displays a small inline icon on each visible method; uncheck it to hide them. Online, Text, Mail, In Person, and Other have package-owned icons that do not require network assets.

Cards now use tighter internal spacing and a slightly smaller QR so a method with an icon, title, QR, and URL note fits inside the fixed card height. Tiles retain their previous spacing. Very long method text still needs a visual check; the package is not yet a general automatic text-layout engine.

Introduction and Closing Message render the documented CRS Markdown subset, including emphasis, headings, lists, escapes, and line breaks. Footer Messages is a multiline editor: **each nonempty line is a separate marquee message**. It may contain `{CID.Name}` or other valid references. Divider appears only between the lines. End Marker appears after the final line of each loop; **Show Start Marker** optionally places the same marker before the first line. Closing Message starts in regular type; Markdown emphasis supplies italics when requested. The track repeats enough messages to span the output width, then scrolls a duplicated lane continuously. Entrance Speed and Marquee Speed remain independent.

The footer is text only. If a QR reference is inserted into a Footer Messages line by accident, the resolved image data would otherwise appear as a long base64 string. This revision omits that line from the marquee. Remove the QR reference from Footer Messages and put it in a method's Displayed Details if you want the image shown. Other valid footer lines continue to scroll.

**Indent Closing Paragraphs** defaults on and indents the first line of each Closing Message paragraph by `1.5em`. A blank line starts another paragraph and indents its first line. For a left-aligned citation, enter it on the next line without a blank line; the Markdown renderer inserts a line break in the same paragraph. For example:

```text
**Every man according as he purposeth in his heart, so let him give.**
-2 Corinthians 9:7
```

Uncheck the option for no paragraph indentation. Spaces are not used for layout; the proportional indent stays consistent when the page is framed. The citation remains author text rather than a required separate field.

The Page Theme uses CRS's existing Theme control. CRS Themes supply resolved colors and fonts to the HTML; Bake freezes them for Guest portability. A Theme with very similar text and background colors may still need a design review. Logo Source offers Church Identity or a Custom Image selected in Media Details. The package contains no sample church logos. Set a Church Identity name and logo before Bake; the manifest declares `church.name` and `church.logo`.

Suggested test: enter a valid Saved Link token in a Method Title and its QR in Displayed Details; enter a Markdown closing; add several footer lines including `{CID.Name}`; compare Cards and Tiles; choose a custom CRS Theme; add four methods in Cards, then switch to Tiles. CRS preserves the fourth row for editing, reports the limit, and requires reducing to three before Bake. Queue a baked item and open the Service Plan in the separate Guest workspace for portability testing.

The controls follow the Announcements pattern: Global Settings first, then Giving Message, repeatable Giving Methods, and Footer. All prior control IDs and value types remain unchanged. Music is an optional CRS audio file selection in Global Settings. It loops independently of the marquee, and an empty Music field stays silent. The embedded Media Details preview should be muted; Enlarge requires the operator to enable preview sound. Check live sound and Guest portability with a music file after Bake.
