# Tithes & Offerings -- version 1.0.4 (en-US)

This is a downloadable CRS-aware HTML package and a structured giving-page example. **Cards** follows Smalltown and supports up to four giving methods. **Tiles** follows Anytown and supports up to three. The CRS Theme selector offers Crimson & Gold, Navy & Gold, and Forest & Cream HTML presets, along with the Host's CRS Themes. Logo Side and theme are independent of layout.

Import this ZIP as a Custom HTML item. Add your church content in Media Details, check Draft Preview, then Bake. Saved content is carried in Service Plans; the ZIP itself contains no church giving details.

With **Animated Entrance** enabled, the logo panel slides in from its selected side, carrying the logo, church name, and Brand Line together. The giving text and methods follow their staggered entrance. **Entrance Speed** sets the panel's motion speed. Turning Animated Entrance off shows the scene immediately. Restart or a Draft state update replays the entrance; resizing keeps the current composition. The package respects the operating system's reduced-motion preference. The background revealed behind the sliding panel follows the selected HTML or CRS Theme.

Message, method, and footer text start empty. Placeholder hints do not appear in Draft Preview or Bake. Method Title, Displayed Details, Small Note, Introduction, Closing Message, and Footer Messages accept Church Identity references. For example, insert `{CID.LinkName.Giving.Donation}` in Method Title, `{CID.QR.Giving.Donation}` in Displayed Details, and `{CID.Link.Giving.Donation}` in Small Note after saving a Giving link named Donation in Church Identity. A QR data URL resolves to an inline image in Displayed Details. Invalid references remain visible in Draft Preview with a red outline around the field and prevent Bake.

The demo label beneath the church name has been removed. **Brand Line** is optional and starts blank. Enter a short custom line, or insert `{CID.Saying}` to use the current Host Church Saying; an empty line is hidden. Bake freezes the resolved saying for Guest playback.

The stray decorative strips at the top of the Cards composition have been removed. **Method Kind** remains an editor choice used to select an icon, but the kind name is not printed on the HTML. **Show Method Icons** defaults on and displays a small inline icon on each visible method; uncheck it to hide them. Online, Text, Mail, In Person, and Other have package-owned icons that do not require network assets.

Cards now use tighter internal spacing and a slightly smaller QR so a method with an icon, title, QR, and URL note fits inside the fixed card height. Tiles retain their previous spacing. Very long method text still needs a visual check; the package is not yet a general automatic text-layout engine.

Introduction and Closing Message render the documented CRS Markdown subset, including emphasis, headings, lists, escapes, and line breaks. Footer Messages is a multiline editor: **each nonempty line is a separate marquee message**. It may contain `{CID.Name}` or other valid references. Divider appears only between the lines. End Marker appears after the final line of each loop; **Show Start Marker** is off by default; enable it to place the same marker before the first line. Existing saved settings retain their chosen value. Closing Message starts in regular type; Markdown emphasis supplies italics when requested. The track repeats enough messages to span the output width, then scrolls a duplicated lane continuously. Entrance Speed and Marquee Speed remain independent.

The footer is text only. Its editor label and placeholder explain that Logo and QR references belong elsewhere. Names, sayings, addresses, phone numbers, and saved-link text are supported. The package removes resolved Church Identity/custom logo sources and inline QR image data from the marquee while preserving other text on the same line; image-only lines are omitted. The editor still offers the shared CRS reference suggestions, so select text references for this field. Put QR references in a method's Displayed Details and logos in the logo panel.

Closing Message starts empty and offers this thank-you placeholder, which does not appear in Draft Preview or Bake until you enter your own message:

```text
Thank you for your faithful giving.
Your generosity supports the ministry and outreach of {CID.Name}.
```

Markdown and Church Identity references remain available for a church's own wording.

**Indent Closing Paragraphs** defaults on and indents the first line of each Closing Message paragraph by `1.5em`. A blank line starts another paragraph and indents its first line. A single newline keeps the next line in the same paragraph. Uncheck the option for no paragraph indentation. Spaces are not used for layout; the proportional indent stays consistent when the page is framed.

The Page Theme uses CRS's existing Theme control. CRS Themes supply resolved colors and fonts to the HTML; Bake freezes them for Guest portability. A Theme with very similar text and background colors may still need a design review. Logo Source offers Church Identity or a Custom Image selected in Media Details. The package contains no sample church logos. Set a Church Identity name and logo before Bake; the manifest declares `church.name` and `church.logo`.

Suggested test: enter a valid Saved Link token in a Method Title and its QR in Displayed Details; enter a Markdown closing; add several footer lines including `{CID.Name}`; compare Cards and Tiles; choose a custom CRS Theme; add four methods in Cards, then switch to Tiles. CRS preserves the fourth row for editing, reports the limit, and requires reducing to three before Bake. Queue a baked item and open the Service Plan in the separate Guest workspace for portability testing.

The controls follow the Announcements pattern: Global Settings first, then Giving Message, repeatable Giving Methods, and Footer. All prior control IDs and value types remain unchanged. Music is an optional CRS audio file selection in Global Settings. Its optional Play Length and Loop Audio are independent of the marquee. An empty Music field stays silent. See MUSIC_CONTROLS.md for offset, delay, fades and ending behavior. The embedded Media Details preview should be muted; Enlarge requires the operator to enable preview sound. Check live sound and Guest portability with a music file after Bake.

The Cards panel meets the logo rail at the tan/color boundary without a thin
stray gutter. The edge treatment mirrors when Logo Side is Right. This
package is designed for a 16:9 output. CRS should fit it uniformly and keep
any area outside the page black, independent of the selected Theme.

## CRS Theme color mapping

| Visible area | CRS Theme color |
| --- | --- |
| Page and giving-method backgrounds | Background |
| Main content panel | Card surface |
| Logo panel (`.brand`) | Background alternate (Background fallback) |
| Main heading, method titles, and church name | Primary |
| Introduction, closing message, and giving details | Text Primary |
| Small notes | Text Secondary |
| Intro Label, method icons, divider, panel border, and Brand Line | Accent |
| Giving-method borders | Secondary |
| Marquee background | Primary |
| Marquee text | Background |
| Marquee top border | Accent |

Built-in HTML Themes use package-owned palettes with separate panel, text, and accent colors. CRS Themes use the mappings above. The sliding logo panel reveals the selected Theme's page background. Images retain their own colors, including any white background embedded in a logo; use a transparent logo if you want the panel color to show through. QR images keep a white background for scanning. Check contrast after selecting a Theme.


## Music control notes

Choose Music to reveal its controls. Use the adjacent info buttons for short
explanations. Time fields accept whole seconds or mm:ss; fade fields accept
decimal seconds. Invalid time text keeps the last valid value until corrected.

- **Start Offset (mm:ss)**: Enter whole seconds or mm:ss. For example, 15 and 00:15 both skip fifteen seconds inside the song. This does not add a silent delay.
- **Fade In (seconds)**: Fade duration in seconds; 0 disables it. Begins when audio starts playing. Natural music repeats do not repeat the opening fade.
- **Start Delay (mm:ss)**: Enter whole seconds or mm:ss. Wait before starting at Start Offset. The delay is separate from the position inside the song.
- **Fade Out (seconds)**: Fade duration in seconds; 0 disables it. Finishes at the selected segment or file ending. Applies at each audio repeat and is bounded by the segment length.
- **Play Length (mm:ss)**: 00:00 plays to the end of the audio file. Otherwise enter duration after Start Offset, using whole seconds or mm:ss. Start Delay does not count toward this length. A shorter file ends sooner.
- **Loop Audio**: Repeat the selected audio segment from Start Offset. Opening delay and fade-in apply once; fade-out applies at every segment ending.

Save stores authoring settings. Explicitly Re-Bake to change live output.
Enlarged preview sound is enabled separately and uses its own remembered volume
and audio output. The main Preview stays silent.
