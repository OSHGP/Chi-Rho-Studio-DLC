# Prayer List -- version 1.0.2 (en-US)

This is a downloadable CRS-aware HTML Prayer List package and an example for authors building their own packages. The full canvas uses a fixed title and church name, a large reading area, and a vertical list of prayer groups. It does not add a fake card border inside the Media output.

Import the ZIP as a new Custom HTML item in a test CRS workspace. Fill out **Prayer Groups** in Media Details and use **Draft Preview** before Bake. Each group has an optional heading, Markdown requests, and a Show This Group checkbox. Add and reorder groups with the CRS-owned repeatable controls. The page title starts as “Prayer List”; subtitle and prayer content start empty. Placeholder examples in the editor are not published content.

The package uses the documented Markdown subset: paragraphs, line breaks, `*italic*`, `**bold**`, `***bold italic***`, headings, and simple ordered or unordered lists. All entered text is rendered as text nodes; the package does not interpret authored HTML. One group can hold multiple requests as Markdown bullet lines. Nested repeatable items are not part of the current CRS contract.

**Loop When Scrolling** starts on and **Scroll Speed** starts at 1. When the content is taller than the reading area, Loop on starts the first group fully below the visible area, scrolls it upward, and repeats after the last group leaves the top. Loop off starts with the first group lower in the visible reading area so it remains on screen through a queue transition, scrolls once, and holds the end. When all the content fits, it stays still regardless of Loop and Speed. The current CRS manifest cannot hide or disable a native checkbox based on the rendered HTML height, so Loop remains visible in Media Details even when it has no effect. CRS’s existing **Restart** button reloads Draft Preview to replay the motion. The package reduces motion if the operating system requests it.

The Page Theme presets are **Warm Paper** and **Evening Blue**. The Page Theme selector also accepts CRS application Themes, including Themes an operator makes for light or dark text over images; the HTML uses their resolved color and font values. Church name comes from Church Identity and can be hidden. No network resources or script dependencies are used. The prayer list is stored with a Bake for Service Plan and Guest playback.

**Custom Background Image**, directly below Page Theme in Global Settings, is optional. With no image selected, the Theme background displays as before. Choose an image from Media Details to use it behind the entire Prayer List. CRS stores the selected image in the scene workspace and includes it in Bake, so the saved Service Plan and Guest item can use it. The Theme still sets the text, accent, and fonts, while the image keeps its original colors. Choose a quiet image with room for text and check that the requests remain readable in Draft Preview and on the 16:9 output. Clear the image to return to the Theme background.

Suggested manual pass: add three groups with short and long requests, lists and emphasis; reorder and hide one group; compare Loop off/on and Speed 0.5/2; Restart and Bake; then try Fullscreen and Large Framed Media at 16:9. Select a background image, switch Themes, clear the image, and check readability before a live service. If there are no filled groups, the preview explicitly asks for a group rather than supplying fictional requests.

Controls follow the Announcements pattern: Global Settings, then authored Prayer Heading and repeatable Prayer Groups. Existing control IDs and values remain the same. Music is an optional CRS audio file selection in Global Settings. It loops while this scene is playing independently of **Loop When Scrolling**, and an empty Music field stays silent. The embedded Media Details preview should be muted; Enlarge requires the operator to enable preview sound. Check live sound and Guest portability with a music file after Bake.

## CRS Theme color mapping

| Visible area | CRS Theme color |
| --- | --- |
| Page background | Background (Primary fallback) |
| Main heading and prayer text | Text Primary |
| Subtitle, church name, and empty-list message | Text Secondary (Secondary fallback) |
| Intro Label, prayer-group headings, side stripe, decorative lines, list markers, and footer | Accent |

Without an image, the page adds a white highlight and a subtle blend of Background and Accent. The thin header rule uses a package-owned color. Warm Paper and Evening Blue use package-owned palettes. A Custom Background Image replaces the page backdrop without a Theme color overlay; Theme text and accent colors still apply. Choose colors that remain readable against the image.
