# Prayer List -- version 1.0.7 (en-US)

This is a downloadable CRS-aware HTML Prayer List package and an example for authors building their own packages. The full canvas uses a fixed title and church name, a large reading area, and a vertical list of prayer groups. It does not add a fake card border inside the Media output.

Import the ZIP as a new Custom HTML item in a test CRS workspace. Fill out **Prayer Groups** in Media Details and use **Draft Preview** before Bake. Each group has an optional heading, Markdown requests, and a Show This Group checkbox. Add and reorder groups with the CRS-owned repeatable controls. The page title starts as “Prayer List”; subtitle and prayer content start empty. Placeholder examples in the editor are not published content.

The package uses the documented Markdown subset: paragraphs, line breaks, `*italic*`, `**bold**`, `***bold italic***`, headings, and simple ordered or unordered lists. All entered text is rendered as text nodes; the package does not interpret authored HTML. One group can hold multiple requests as Markdown bullet lines. Nested repeatable items are not part of the current CRS contract.

**Loop When Scrolling** starts on and **Scroll Speed** starts at 1. When the content is taller than the reading area, Loop on starts the first group fully below the visible area, scrolls it upward, and repeats after the last group leaves the top. Loop off starts with the first group lower in the visible reading area so it remains on screen through a queue transition, scrolls once, and holds the end. When all the content fits, it stays still regardless of Loop and Speed. The current CRS manifest cannot hide or disable a native checkbox based on the rendered HTML height, so Loop remains visible in Media Details even when it has no effect. CRS’s existing **Restart** button reloads Draft Preview to replay the motion. The package reduces motion if the operating system requests it.

The Page Theme presets are **Warm Paper** and **Evening Blue**. The Page Theme selector also accepts CRS application Themes, including Themes an operator makes for light or dark text over images; the HTML uses their resolved color and font values. Church name comes from Church Identity and can be hidden. No network resources or script dependencies are used. The prayer list is stored with a Bake for Service Plan and Guest playback.

**Custom Background Image**, directly below Page Theme in Global Settings, is optional. With no image selected, the Theme background displays as before. Choose an image from Media Details to use it behind the entire Prayer List. CRS stores the selected image in the scene workspace and includes it in Bake, so the saved Service Plan and Guest item can use it. The Theme still sets the text, accent, and fonts, while the image keeps its original colors. Choose a quiet image with room for text and check that the requests remain readable in Draft Preview and on the 16:9 output. Clear the image to return to the Theme background.

Suggested manual pass: add three groups with short and long requests, lists and emphasis; reorder and hide one group; compare Loop off/on and Speed 0.5/2; Restart and Bake; then try Fullscreen and Large Framed Media at 16:9. Select a background image, switch Themes, clear the image, and check readability before a live service. If there are no filled groups, the preview explicitly asks for a group rather than supplying fictional requests.

Controls follow the Announcements pattern: Global Settings, then authored Prayer Heading and repeatable Prayer Groups. Existing control IDs and values remain the same. Music is an optional CRS audio file selection in Global Settings. Its optional Play Length and Loop Audio are independent of **Loop When Scrolling**. An empty Music field stays silent. See MUSIC_CONTROLS.md for offset, delay, fades and ending behavior. The embedded Media Details preview should be muted; Enlarge requires the operator to enable preview sound. Check live sound and Guest portability with a music file after Bake.

## CRS Theme color mapping

| Visible area | CRS Theme color |
| --- | --- |
| Page background | Background (Primary fallback) |
| Main heading and prayer text | Text Primary |
| Subtitle, church name, and empty-list message | Text Secondary (Secondary fallback) |
| Intro Label, prayer-group headings, side stripe, decorative lines, list markers, and footer | Accent |

Without an image, the page adds a white highlight and a subtle blend of Background and Accent. The thin header rule uses a package-owned color. Warm Paper and Evening Blue use package-owned palettes. A Custom Background Image replaces the page backdrop without a Theme color overlay; Theme text and accent colors still apply. Choose colors that remain readable against the image.


## Music control notes

Choose Music to reveal its controls. Use the adjacent info buttons for short
explanations. Time fields accept whole seconds or mm:ss; fade fields accept
decimal seconds. Invalid time text keeps the last valid value until corrected.

- **Start Offset (mm:ss)**: Enter whole seconds or mm:ss. For example, 15 and 00:15 both skip fifteen seconds inside the song. This does not add a silent delay.
- **Fade In (seconds)**: Fade duration in seconds; 0 disables it. Begins when audio starts playing. Natural music repeats do not repeat the opening fade.
- **Start Delay (mm:ss)**: Enter whole seconds or mm:ss. Wait before starting at Start Offset. The delay is separate from the position inside the song.
- **Fade Out (seconds)**: Fade duration in seconds; 0 disables it. Finishes at the selected segment or file ending. Applies at each audio repeat and is bounded by the segment length.
- **Play Length (mm:ss)**: 00:00 plays to the end of the audio file. Otherwise enter duration after Start Offset, using whole seconds or mm:ss. Start Delay does not count toward this length. A shorter file ends sooner.
- **Loop Audio**: Repeat the selected audio segment from Start Offset. Opening delay and fade-in apply once; fade-out applies at every segment ending.

Save stores authoring settings. Explicitly Re-Bake to change live output.
Enlarged preview sound is enabled separately and uses its own remembered volume
and audio output. The main Preview stays silent.


## Editing preview

With a supporting CRS version, changing controls holds a silent, settled Draft
preview. Restart clears the editing selection and plays from the beginning with
the configured music timing. This changes only Details preview, not saved loop
settings or live output. Older CRS versions retain their previous preview behavior.


## Visual duration estimate -- 1.0.7

Media Details in a supporting CRS build shows an advisory visual estimate beside Restart. Audio offset, delay, fades and play length do not change this visual estimate. This does not stop playback or set audio length automatically.
Scroll duration is measured from the current rendered text and speed, including font/layout changes. Short, empty and reduced-motion lists are Static. The estimate always uses one non-looping reading pass, as if Loop When Scroll were unchecked. Enabling Loop changes playback only, not the reported time.

## Matching music to the estimated reading time

The estimate beside Restart is the visual time for one non-looping reading pass, even when Loop When Scrolling is enabled. Music timing is independent; CRS does not automatically copy this estimate into Play Length.

To finish the music near the estimated end:

1. Choose a track and set Start Offset to skip any unwanted beginning. Start Offset changes the position inside the file; it does not delay playback.
2. Set Start Delay if you want the prayer list to begin before the music.
3. Set Play Length to the estimated reading time minus Start Delay. Turn Loop Audio off so the segment ends instead of repeating. Do not leave Play Length at 00:00 for a timed stop; 00:00 means play to the end of the file.
4. Set Fade Out to the desired fade duration. The fade is included in Play Length, not added afterward.

Example: for an estimate of 01:30 and Start Delay of 00:15, set Play Length to 01:15. With Fade Out set to 5 seconds, music starts at 00:15, begins fading at about 01:25 and ends at about 01:30. A Start Offset of 00:15 would additionally skip the first 15 seconds of the file; it does not add another 15-second wait.

The final prayer requests may still need time to be read after scrolling stops. Allow extra time if wanted, then subtract Start Delay from that longer target. If Start Delay is as long as or longer than the target, reduce the delay or choose a later audio ending. The selected file must have enough audio remaining after Start Offset; a shorter file can end sooner.

Loop When Scrolling controls the prayer list. Loop Audio controls the selected audio segment. To keep music playing across repeated scrolls, leave Loop Audio enabled instead of using the one-pass ending setup above. Changing prayer text or Speed can change the estimate, so review audio timing afterward. Re-Bake saved changes for output. Estimates are approximate; check the result in Presentation or OBS before use.
