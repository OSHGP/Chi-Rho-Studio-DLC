(() => {
  "use strict";

  const page = document.getElementById("page");
  const windowElement = document.getElementById("readingWindow");
  const content = document.getElementById("scrollContent");
  const defaults = {
    page_theme: "html:warm_paper", title: "Prayer List", subtitle: "",
    show_church_name: true, groups: [{ heading: "", requests: "", enabled: true }],
    loop: true, speed: 1, music: ""
  };
  let currentControls = defaults;
  let measureTicket = 0;

  function appendInline(parent, raw) {
    const text = String(raw ?? "");
    let plain = "";
    function flush() {
      if (plain) parent.append(document.createTextNode(plain));
      plain = "";
    }
    for (let index = 0; index < text.length;) {
      if (text[index] === "\\" && /[\\#*.-]/.test(text[index + 1] || "")) {
        plain += text[index + 1];
        index += 2;
        continue;
      }
      if (text[index] === "*" && text[index + 1] !== " ") {
        const count = text.startsWith("***", index) ? 3 : text.startsWith("**", index) ? 2 : 1;
        const delimiter = "*".repeat(count);
        let end = text.indexOf(delimiter, index + count);
        while (end > 0 && text[end - 1] === "\\") end = text.indexOf(delimiter, end + count);
        if (end > index + count) {
          flush();
          const outer = document.createElement(count === 1 ? "em" : "strong");
          const inner = count === 3 ? document.createElement("em") : outer;
          if (count === 3) outer.append(inner);
          appendInline(inner, text.slice(index + count, end));
          parent.append(outer);
          index = end + count;
          continue;
        }
      }
      plain += text[index];
      index += 1;
    }
    flush();
  }

  // Render the small documented Markdown subset as DOM nodes, never HTML strings.
  function renderMarkdown(element, raw) {
    let paragraph = null;
    let list = null;
    for (const line of String(raw ?? "").split(/\r?\n/)) {
      if (!line.trim()) { paragraph = null; list = null; continue; }
      const heading = line.match(/^(#{1,3})\s+(.+)$/);
      const bullet = line.match(/^[-*]\s+(.+)$/);
      const numbered = line.match(/^\d+\.\s+(.+)$/);
      if (heading) {
        paragraph = null; list = null;
        const node = document.createElement(`h${heading[1].length + 2}`);
        appendInline(node, heading[2]);
        element.append(node);
      } else if (bullet || numbered) {
        paragraph = null;
        const tag = bullet ? "ul" : "ol";
        if (!list || list.tagName.toLowerCase() !== tag) {
          list = document.createElement(tag);
          element.append(list);
        }
        const item = document.createElement("li");
        appendInline(item, (bullet || numbered)[1]);
        list.append(item);
      } else {
        list = null;
        if (!paragraph) {
          paragraph = document.createElement("p");
          element.append(paragraph);
        } else paragraph.append(document.createElement("br"));
        appendInline(paragraph, line);
      }
    }
  }

  function setTheme(theme, uses) {
    page.classList.toggle("theme-paper", theme === "html:warm_paper");
    page.classList.toggle("theme-evening", theme === "html:evening_blue");
    if (!String(theme).startsWith("crs:")) {
      for (const property of ["--background", "--ink", "--soft", "--accent", "--display", "--body"])
        page.style.removeProperty(property);
      return;
    }
    const colors = {
      "--background": uses["theme.background"] || uses["theme.primary"],
      "--ink": uses["theme.text_primary"],
      "--soft": uses["theme.text_secondary"] || uses["theme.secondary"],
      "--accent": uses["theme.accent"]
    };
    for (const [property, value] of Object.entries(colors)) {
      if (typeof value === "string" && CSS.supports("color", value))
        page.style.setProperty(property, value);
      else page.style.removeProperty(property);
    }
    for (const [property, key] of [["--display", "theme.display_font_family"], ["--body", "theme.font_family"]]) {
      const font = uses[key];
      if (typeof font === "string" && font && !/[;{}]/.test(font))
        page.style.setProperty(property, font);
      else page.style.removeProperty(property);
    }
  }

  function scheduleMotion() {
    const ticket = ++measureTicket;
    content.classList.remove("moving");
    const measure = () => {
      if (ticket !== measureTicket) return;
      const viewport = windowElement.clientHeight;
      const height = content.scrollHeight;
      const loop = currentControls.loop === true;
      const speed = Math.max(0.5, Math.min(2, Number(currentControls.speed) || 1));
      const hasContent = content.querySelector(".group") !== null;
      const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
      // Short lists remain still regardless of the stored Loop setting.
      if (!hasContent || reduceMotion || height <= viewport) return;
      // A looping run enters from fully below the reading area. A one-time
      // run starts with the first group already visible, as in revision 1.
      const start = loop ? viewport : 0;
      const end = loop ? -height : Math.min(0, viewport - height);
      const pixelsPerSecond = Math.max(12, window.innerHeight * .04 * speed);
      content.style.setProperty("--start", `${start}px`);
      content.style.setProperty("--end", `${end}px`);
      content.style.setProperty("--duration", `${Math.max(1, Math.abs(end - start) / pixelsPerSecond)}s`);
      content.style.setProperty("--iterations", loop ? "infinite" : "1");
      void content.offsetWidth;
      content.classList.add("moving");
    };
    requestAnimationFrame(measure);
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(measure);
  }

  function syncMusic(rawSource) {
    const music = document.getElementById("music");
    const source = typeof rawSource === "string" ? rawSource.trim() : "";
    if (!source) {
      music.pause();
      if (music.hasAttribute("src")) {
        music.removeAttribute("src");
        music.load();
      }
      return;
    }
    if (music.getAttribute("src") !== source) {
      music.pause();
      music.src = source;
      music.load();
    }
    if (music.paused) {
      const playback = music.play();
      if (playback && typeof playback.catch === "function") playback.catch(() => {});
    }
  }

  function applySceneState(state) {
    const controls = { ...defaults, ...(state.controls || {}) };
    const uses = state.resolved_uses || {};
    currentControls = controls;
    syncMusic(controls.music);
    setTheme(controls.page_theme, uses);
    document.getElementById("title").textContent = String(controls.title || "Prayer List");
    const subtitle = document.getElementById("subtitle");
    subtitle.textContent = String(controls.subtitle || "").trim();
    subtitle.hidden = !subtitle.textContent;
    const church = document.getElementById("churchName");
    church.textContent = String(uses["church.name"] || "").trim();
    church.hidden = controls.show_church_name !== true || !church.textContent;

    content.replaceChildren();
    const groups = Array.isArray(controls.groups) ? controls.groups : [];
    for (const group of groups) {
      if (!group || group.enabled === false) continue;
      const heading = String(group.heading || "").trim();
      const requests = String(group.requests || "").trim();
      if (!heading && !requests) continue;
      const section = document.createElement("section");
      section.className = "group";
      if (heading) {
        const title = document.createElement("h2");
        title.className = "group-heading";
        title.textContent = heading;
        section.append(title);
      } else section.classList.add("no-heading");
      const body = document.createElement("div");
      body.className = "group-body";
      renderMarkdown(body, requests);
      section.append(body);
      content.append(section);
    }
    if (!content.childElementCount) {
      const hint = document.createElement("div");
      hint.className = "empty";
      hint.textContent = "Add a prayer group in Media Details to begin.";
      content.append(hint);
    }
    scheduleMotion();
  }

  window.addEventListener("message", (event) => {
    const state = event.data;
    if (!state || state.type !== "chi-rho-scene-state" ||
        state.schema !== "chi-rho-studio.scene-state" || state.version !== 1) return;
    applySceneState(state);
  });
  window.addEventListener("resize", scheduleMotion);
  applySceneState({ controls: defaults, resolved_uses: {} });
})();
