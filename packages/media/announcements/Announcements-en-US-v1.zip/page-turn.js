/* Announcements Page Turn integration trial. Continuous clipped HTML front and theme-colored paper back. */
(function(root){
 'use strict';
 let diagnosticSerial=0,lastReceipt=null;
 const PALETTE=['--page','--card-border','--primary','--accent','--accent-secondary','--text','--secondary','--font'];
function clip(poly,n,c,keep){
 const out=[];for(let i=0;i<poly.length;i++){
  const a=poly[i],b=poly[(i+1)%poly.length],da=(a.x*n.x+a.y*n.y-c)*keep,db=(b.x*n.x+b.y*n.y-c)*keep;
  if(da>=0)out.push(a);
  if((da>0&&db<0)||(da<0&&db>0)){const t=da/(da-db);out.push({x:a.x+t*(b.x-a.x),y:a.y+t*(b.y-a.y)});}
 }return out;
}
function geometry(w,h,t){
 t=Math.max(0,Math.min(1,t));
 const phase=t*t*(3-2*t),slope=.10+.16*Math.sin(Math.PI*phase);
 const n={x:1,y:slope},r=[{x:0,y:0},{x:w,y:0},{x:w,y:h},{x:0,y:h}];
 const c=(w+slope*h)*(1-phase);
 const front=clip(r,n,c,-1),fold=clip(r,n,c,1),nn=1+slope*slope;
 const back=fold.map(p=>{const d=2*(p.x+slope*p.y-c)/nn;return {x:p.x-d,y:p.y-slope*d};});
 return {front,back,c,n};
}
 // Theme colors are hex or computed rgb(). Mix in encoded RGB so each
 // channel moves equally toward white/black, preserving the color family.
 function paperBackColor(color){
  const value=String(color).trim();let rgb;
  if(/^#[0-9a-f]{3}$/i.test(value))rgb=[...value.slice(1)].map(c=>parseInt(c+c,16));
  else if(/^#[0-9a-f]{6}$/i.test(value))rgb=[1,3,5].map(i=>parseInt(value.slice(i,i+2),16));
  else {const m=value.match(/^rgb\(\s*([\d.]+)\s*,\s*([\d.]+)\s*,\s*([\d.]+)\s*\)$/i);if(m)rgb=m.slice(1).map(Number);}
  if(!rgb||rgb.some(v=>!Number.isFinite(v)||v<0||v>255))return color;
  const brightness=.2126*rgb[0]+.7152*rgb[1]+.0722*rgb[2];
  const target=brightness<128?255:0;
  return '#'+rgb.map(v=>Math.round(v*.75+target*.25).toString(16).padStart(2,'0')).join('');
 }
 function freeze(stage){
  const snapshot=stage.cloneNode(true),style=getComputedStyle(stage);
  for(const name of PALETTE)snapshot.style.setProperty(name,style.getPropertyValue(name));
  snapshot.removeAttribute('id');
  for(const node of snapshot.querySelectorAll('[id]'))node.removeAttribute('id');
  snapshot.setAttribute('aria-hidden','true');snapshot.setAttribute('inert','');
  snapshot.style.pointerEvents='none';snapshot.style.opacity='1';snapshot.style.transition='none';
  return snapshot;
 }
 function create({scene,stage,duration,complete,diagnostics=false}){
  const box=stage.getBoundingClientRect(),width=box.width,height=box.height;
  if(!(width>0&&height>0))return null;
  const turnId=diagnostics?++diagnosticSerial:0;
  const previousReceipt=lastReceipt;
  let callbackState='not called',holderRemoved=false;
  function receipt(state){
   if(!diagnostics)return;
   lastReceipt={id:turnId,state,progress:lastProgress,elapsed:lastElapsed,callback:callbackState,holderRemoved};
   console.info('[CRS Page Turn] '+JSON.stringify(lastReceipt));
  }
  const snapshot=freeze(stage),paper=snapshot.style.getPropertyValue('--page').trim()||'#111827';
  const edgeColor=snapshot.style.getPropertyValue('--card-border').trim()||snapshot.style.getPropertyValue('--accent').trim()||'#ffffff';
  const holder=document.createElement('div');
  Object.assign(holder.style,{position:'absolute',inset:'0',zIndex:'5',overflow:'hidden',pointerEvents:'none',isolation:'isolate'});
  holder.setAttribute('aria-hidden','true');holder.setAttribute('inert','');
  holder.appendChild(snapshot);scene.appendChild(holder);
  // A sibling of the turning holder, never cloned into the turning page.
  const label=diagnostics?document.createElement('div'):null;
  if(label){
   Object.assign(label.style,{position:'absolute',left:'8px',right:'8px',bottom:'8px',zIndex:'2147483647',background:'#101010',color:'#ffffff',border:'1px solid #ffffff',padding:'6px 10px',font:'16px monospace',lineHeight:'1.4',pointerEvents:'none',whiteSpace:'normal'});
   label.setAttribute('aria-hidden','true');scene.appendChild(label);
  }
  let lastProgress=0,lastElapsed=0,probeTimer=0,diagnosticClosed=false;
  function report(state,t=lastProgress,elapsed=lastElapsed){
   lastProgress=t;lastElapsed=elapsed;
   if(label){
    const previous=previousReceipt?`Previous #${previousReceipt.id}: ${previousReceipt.state}; callback ${previousReceipt.callback}; layers removed ${previousReceipt.holderRemoved?'yes':'no'}`:'Previous: none';
    label.textContent=`Page Turn #${turnId} | ${state} | Progress: ${(t*100).toFixed(1)}% | Elapsed: ${Math.round(elapsed)} / ${Math.round(duration)} ms | Callback: ${callbackState} | ${previous}`;
   }
  }
  report('Waiting for image');
  if(diagnostics)console.info('[CRS Page Turn] start #'+turnId+' duration='+duration+'ms');
  receipt('Started');
  let raf=0,disposed=false,started=false,startTime=null,waitTimer=0,waiting=[];
  let back,shade;
  function removeWait(){clearTimeout(waitTimer);waitTimer=0;for(const [im,f] of waiting){im.removeEventListener('load',f);im.removeEventListener('error',f);}waiting=[];}
  function dispose(keepLabel=false){
   if(keepLabel!==true){diagnosticClosed=true;clearTimeout(probeTimer);probeTimer=0;}
   if(label&&keepLabel!==true)label.remove();
   if(disposed)return;disposed=true;cancelAnimationFrame(raf);raf=0;removeWait();holder.remove();holderRemoved=true;
   window.removeEventListener('resize',finish);window.removeEventListener('pagehide',dispose);document.removeEventListener('visibilitychange',onVisibility);
   if(keepLabel!==true)receipt('Cancelled');
  }
  function finish(reason='Finished early'){
   if(disposed)return;
   const state=typeof reason==='string'?reason:'Finished early';
   report(state);dispose(true);
   callbackState='entered';receipt(state);
   try{complete();callbackState='returned';}
   catch(error){callbackState='threw';receipt(state);report(state);throw error;}
   receipt(state);report(state);
   // One diagnostic repaint request, never a playback recovery loop.
   if(label&&!diagnosticClosed){
    probeTimer=setTimeout(()=>{
     probeTimer=0;if(diagnosticClosed)return;
     report(state+' | Post-completion probe +250 ms');
     label.style.background='#17374d';
     console.info('[CRS Page Turn] repaint probe #'+turnId+' callback='+callbackState);
    },250);
   }
  }
  function onVisibility(){if(document.hidden)finish('Hidden: finished early');}
  function polygon(points){return points.length>=3?'polygon('+points.map(p=>p.x+'px '+p.y+'px').join(',')+')':'polygon(0px 0px,0px 0px,0px 0px)';}
  function build(){
   // Retain the integration's content guard; clone the outgoing HTML only once.
   if(snapshot.querySelectorAll('*').length>125){finish('Cut: content limit');return false;}
   Object.assign(snapshot.style,{position:'absolute',inset:'0',width:width+'px',height:height+'px',zIndex:'2'});
   back=document.createElement('div');shade=document.createElement('div');
   Object.assign(back.style,{position:'absolute',inset:'0',backgroundColor:paperBackColor(paper),zIndex:'4',pointerEvents:'none'});
   Object.assign(shade.style,{position:'absolute',transformOrigin:'0 0',zIndex:'3',pointerEvents:'none'});
   holder.appendChild(shade);holder.appendChild(back);draw(0);return true;
  }
  function draw(t){
   const g=geometry(width,height,t),angle=Math.atan(g.n.y)*180/Math.PI;
   snapshot.style.clipPath=polygon(g.front);back.style.clipPath=polygon(g.back);
   back.style.display=t===0?'none':'block';shade.style.display=t===0?'none':'block';
   const length=Math.hypot(width,height)*3;
   Object.assign(shade.style,{width:length+'px',height:length+'px',left:g.c+'px',top:'0',
    transform:'rotate('+angle+'deg) translate(-100%,-50%)',
    background:'linear-gradient(to right,transparent calc(100% - '+Math.min(60,width*.06)+'px),rgba(0,0,0,.23))',opacity:String(Math.sin(Math.PI*t))});
   const extent=width+g.n.y*height,crease=g.c/extent*100,band=Math.min(95,width*.10/extent*100);
   // A narrow crease highlight with an adjacent soft shadow. Express its
   // width in perpendicular screen pixels, then convert to gradient stops.
   // This stays on the one continuous back surface, with no extra face seams.
   const unit=Math.hypot(g.n.x,g.n.y)/extent*100;
   const edge=Math.max(1.2,Math.min(3,width/640))*unit;
   const soft=Math.max(8,Math.min(24,width*.014))*unit;
   back.style.backgroundImage=`linear-gradient(${90+angle}deg,transparent ${crease-soft*2}%,rgba(0,0,0,.22) ${crease-soft}%,rgba(0,0,0,.32) ${crease-edge*2}%,color-mix(in srgb, ${edgeColor} 52%, transparent) ${crease-edge}%,color-mix(in srgb, ${edgeColor} 24%, transparent) ${crease}%),linear-gradient(${90+angle}deg,rgba(0,0,0,.08) ${crease-band*2}%,rgba(255,255,255,.14) ${crease-band*.8}%,rgba(0,0,0,.1) ${crease-band*.2}%,rgba(0,0,0,.26) ${crease}%)`;
  }
  function tick(now){
   raf=0;if(disposed)return;
   if(startTime===null)startTime=now;
   const t=Math.min(1,Math.max(0,(now-startTime)/Math.max(1,duration)));
   report('Running',t,Math.min(Math.max(0,now-startTime),Math.max(1,duration)));
   if(t>=1){finish('Complete');return;}
   draw(t);
   raf=requestAnimationFrame(tick);
  }
  function begin(){
   if(disposed||started)return;started=true;removeWait();
   if(document.hidden){finish('Hidden: finished early');return;}
   if(build())raf=requestAnimationFrame(tick);
  }
  function start(images=[]){
   if(disposed||started)return;
   const pending=images.filter(im=>!im.complete);let left=pending.length;
   for(const im of pending){let settled=false;const ready=()=>{if(settled)return;settled=true;if(--left===0)begin();};waiting.push([im,ready]);im.addEventListener('load',ready);im.addEventListener('error',ready);if(im.complete)ready();}
   if(left>0&&!started)waitTimer=setTimeout(begin,3000);else begin();
  }
  window.addEventListener('resize',finish);window.addEventListener('pagehide',dispose);document.addEventListener('visibilitychange',onVisibility);
  return {start,dispose};
 }
 const api={create,geometry,paperBackColor};
 if(typeof module==='object'&&module.exports)module.exports=api;else root.CRSPageTurn=api;
})(typeof window==='undefined'?globalThis:window);
