/* Package-owned music envelope. Host output gain/mute remains independent. */
(function(root){
 'use strict';
 function seconds(value,fallback,max){const n=Number(value);return Number.isFinite(n)?Math.max(0,Math.min(max,n)):fallback;}
 function delaySeconds(value){
  const text=String(value??'').trim();
  if(/^[0-9]{1,4}$/.test(text))return Math.min(3600,Number(text));
  const m=text.match(/^([0-9]{1,3}):([0-5][0-9])$/);
  return m?Math.min(3600,Number(m[1])*60+Number(m[2])):0;
 }
 function create(audio,clock={now:()=>performance.now(),frame:f=>requestAnimationFrame(f),cancelFrame:id=>cancelAnimationFrame(id),timer:(f,ms)=>setTimeout(f,ms),cancelTimer:id=>clearTimeout(id)}){
  let generation=0,disposed=false,raf=0,startTimer=0,endTimer=0,options={},gain=1,fadeOutStart=null,playingListener=null,prepareTimer=0,prepareListeners=[],endedListener=null;
  function clearPreparation(){
   clock.cancelTimer(prepareTimer);prepareTimer=0;
   for(const [name,fn] of prepareListeners)audio.removeEventListener(name,fn);prepareListeners=[];
  }
  function setGain(value){gain=Math.max(0,Math.min(1,value));audio.volume=gain;}
  function cancel(){
   generation++;clearPreparation();
   if(endedListener)audio.removeEventListener('ended',endedListener);endedListener=null;
   clock.cancelFrame(raf);clock.cancelTimer(startTimer);clock.cancelTimer(endTimer);
   raf=startTimer=endTimer=0;fadeOutStart=null;
   if(playingListener)audio.removeEventListener('playing',playingListener);playingListener=null;
  }
  function stop(){cancel();audio.pause();}
  function ramp(from,to,duration,done){
   clock.cancelFrame(raf);raf=0;
   const token=generation,begin=clock.now();
   function tick(){
    if(disposed||token!==generation)return;
    const p=Math.min(1,Math.max(0,(clock.now()-begin)/Math.max(1,duration)));
    setGain(from+(to-from)*p);
    if(p<1)raf=clock.frame(tick);else{raf=0;if(done)done();}
   }
   tick();
  }
  function beginFadeOut(){
   if(disposed||!options.stopAtEnd)return;
   fadeOutStart=clock.now();clearPreparation();
   // Cancel a delayed start, and never restart a song that already ended.
   clock.cancelTimer(startTimer);startTimer=0;
   if(playingListener)audio.removeEventListener('playing',playingListener);playingListener=null;
   ramp(gain,0,options.fadeOutMs);
  }
  function start(controls){
   if(disposed)return;
   stop();options={stopAtEnd:controls.music_stop_at_end===true,
    fadeInMs:seconds(controls.music_fade_in_seconds,0,30)*1000,
    fadeOutMs:seconds(controls.music_fade_out_seconds,0,30)*1000};
   const token=generation,source=typeof controls.music==='string'?controls.music:'';
   try{audio.currentTime=0;}catch(_error){}
   if(!source){audio.removeAttribute('src');audio.load();setGain(1);return;}
   if(audio.getAttribute('src')!==source){audio.src=source;audio.load();}
   const offset=delaySeconds(controls.music_start_offset);
   // Native loop returns to zero. With an offset, repeat via the same bounded
   // seek path so recorded opening silence is skipped on every music repeat.
   const loopAudio=typeof controls.music_loop==='boolean'?controls.music_loop:controls.loop===true;
   audio.loop=loopAudio&&offset===0;
   function prepare(done){
    if(!offset){done();return;}
    clearPreparation();let seeking=false;
    function listen(name,fn){prepareListeners.push([name,fn]);audio.addEventListener(name,fn);}
    function valid(){return !disposed&&token===generation&&fadeOutStart===null;}
    function ready(){if(!valid())return;clearPreparation();done();}
    function metadata(){
     if(!valid()||seeking)return;
     if(Number.isFinite(audio.duration)&&offset>=audio.duration){clearPreparation();return;}
     seeking=true;
     listen('seeked',ready);
     try{audio.currentTime=offset;}catch(_error){clearPreparation();return;}
     if(!audio.seeking&&Math.abs(audio.currentTime-offset)<.05)ready();
    }
    listen('loadedmetadata',metadata);listen('error',clearPreparation);
    prepareTimer=clock.timer(clearPreparation,10000);
    if(audio.readyState>=1)metadata();
   }
   if(loopAudio&&offset>0){endedListener=()=>play(true);audio.addEventListener('ended',endedListener);}
   setGain(options.fadeInMs?0:1);
   function play(repeat=false){
    startTimer=0;if(disposed||token!==generation||fadeOutStart!==null)return;
    prepare(()=>{
    if(options.fadeInMs&&!repeat){
     playingListener=()=>{audio.removeEventListener('playing',playingListener);playingListener=null;
      if(!disposed&&token===generation&&fadeOutStart===null)ramp(0,1,options.fadeInMs);};
     audio.addEventListener('playing',playingListener);
    }
    try{const result=audio.play();if(result&&typeof result.catch==='function')result.catch(()=>{
     if(token===generation&&playingListener){audio.removeEventListener('playing',playingListener);playingListener=null;}
    });}catch(_error){if(playingListener)audio.removeEventListener('playing',playingListener);playingListener=null;}
    });
   }
   const delay=delaySeconds(controls.music_delay_time)*1000;
   if(delay)startTimer=clock.timer(play,delay);else play();
  }
  function finalSlide(durationMs){
   if(disposed||!options.stopAtEnd)return;
   clock.cancelTimer(endTimer);
   const token=generation;
   // The caller ends/replays the cycle at durationMs. Fade fits inside that hold.
   if(options.fadeOutMs>0){const fade=Math.min(options.fadeOutMs,durationMs);options.fadeOutMs=fade;
    endTimer=clock.timer(()=>{endTimer=0;if(!disposed&&token===generation)beginFadeOut();},Math.max(0,durationMs-fade));}
  }
  function dispose(){if(disposed)return;stop();disposed=true;}
  return {start,stop,finalSlide,dispose};
 }
 const api={create,delaySeconds};if(typeof module==='object'&&module.exports)module.exports=api;else root.CRSMusicPlayback=api;
})(typeof window==='undefined'?globalThis:window);
