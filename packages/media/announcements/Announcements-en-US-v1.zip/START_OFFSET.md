# Start Offset — 1.0.28

Enter 15 or 00:15 to skip fifteen seconds inside the selected song. Start Delay
is separate: 00:15 waits fifteen seconds before playing at that offset.

Offset applies on Restart, whole-show replay and natural audio repeats. Playback
waits for metadata and seek completion; an offset beyond the song stays silent.
See MUSIC_CONTROLS.md for revised numeric fades, independent Loop Audio, validation,
prototype-update notes and the complete acceptance checklist.
