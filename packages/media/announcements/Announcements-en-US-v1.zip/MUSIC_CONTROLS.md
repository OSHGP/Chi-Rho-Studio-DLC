# Announcements music controls — 1.0.28 trial

Apply the accompanying CRS patch before importing this package update. It adds
native duration entry, audio-presence visibility and original filename display;
it does not change the audio engine or its output routing. Do not publish yet.
Prayers and Tithes have not been changed.

## Controls

Choose/Clear and the selected filename are always visible. The remaining music
controls appear when audio is selected; Clear hides them without discarding their
values. The UUID remains the stored asset name. Previously imported audio with
no filename metadata still displays its internal name; choose the original file
again once to record its display name. Display names are literal plain text.

- Start Offset: skip opening audio (15 or 00:15 skips fifteen seconds). This is a
  position in the song, not a silent wait. Repeats also return to that offset.
- Fade In: seconds, default 0.25. Set 0 to disable. Starts on actual playback.
- Start Delay: seconds or mm:ss, default 00:00. A delay of 15 means fifteen seconds
  of silence before starting at the chosen offset. This is separate from offset.
- Fade Out: seconds, default 0.25; 0 disables. Only applies with Stop at End.
- Stop at End: off by default. On: fade/stop after the final enabled slide's full
  hold duration, leaving its final picture visible. Does not advance the queue.
- Loop Audio: on by default. Repeats the song independently of Loop Slides.
  Repeating audio alone does not reapply the opening delay or fade.

For continuously rotating announcements, leave Stop at End off and Loop Audio on.
For a video-like show, enable Stop at End; Loop Slides then restarts the whole
music sequence at each slideshow wrap. With Loop Slides off, the final view holds
in silence. Stop at End takes precedence over Loop Audio at the show boundary.
With Loop Audio off, a short song can end before the slideshow does.

Time entry accepts whole seconds or mm:ss, from 0 through 3600 seconds. Valid input
normalizes to mm:ss when leaving the field. An invalid draft shows a warning icon
and explanation; Preview and Save keep the last valid value until corrected.

## Updating the private prototype

The old Fade In, Delay Start and Fade Out checkboxes are removed. Their duration
values now operate directly: zero disables. Review these values after updating,
especially an old saved 00:15 delay or 0.25 fade whose former checkbox was off.
Loop Audio is new and defaults on; explicitly turn it off if desired. No existing
baked scene changes until you explicitly Re-Bake. Existing 1.0.27 functional audio
checks passed locally; this revised UI/behavior still needs acceptance.

Restart/source replacement cancels prior delays/fades/seeks. An offset at or beyond
song duration stays silent. A delayed start cannot begin after the ending fade.
Output gain/mute and independent enlarged-preview routing remain host-owned.

The slideshow retains its existing scheduling: each hold begins after its incoming
transition completes. This is video-like replay, not sample-accurate AV scheduling.
Return from single-slide authoring focus to whole-show preview for ending checks.

## Local acceptance

1. Choose Piano.wav; verify its name, Clear/no-audio state, reselect, Save/reopen,
   Prev/Next and app restart. Older UUID names require choosing the original once.
2. Enter 15 and 00:15 for offset and delay. Verify equivalent timing; test 75,
   01:15, zero and invalid input. Invalid text should show a warning and retain
   the previous valid saved/preview value. Correct it and verify recovery.
3. Set fades to 2 seconds, then 0. Compare Loop Audio on/off with Loop Slides
   on/off and a song shorter than the show. Test an offset with audio repeating.
4. Stop at End on: final fade, held picture, and looped slideshow restarting the
   offset/delay/fade. Stop at End off: continuous music across slide wraps.
5. Restart during delay/fade, close Enlarge/Details, and switch queued item.
   Verify no stale audio or blank/duplicated preview. Re-Bake and compare Preview,
   Presentation and OBS, including Quick Volume/Mute and enlarged-preview sound.

Automated output is in TEST_RESULTS.txt in the outer review ZIP. Mocked audio and
offscreen Qt checks do not establish audible playback on the authoritative machine.
