# Announcements en-US, version 1.0.32 (music controls trial)

A Custom HTML package for creating announcement slides in Chi Rho Studio (CRS).
Install the ZIP through the CRS Media Library. To study or adapt the package,
unzip it and edit `crs-scene.json` and `index.html`.

Requires a CRS build with per-slide Theme support (introduced on the
`0.15.1jp` branch at commit `37b0715`).

## Controls

Global Settings include Transition (Cut, Fade through black, Crossfade, Page Turn),
Transition Duration (0.2 to 2.0 seconds for animated transitions), Default
Duration, Loop, optional Music, and Theme. Cut is immediate.

Add slides in Media Details. A slide can inherit the Global Theme or select an
HTML, Media Scene, or specific CRS Theme. Text slides support a title, optional
underline, Markdown body, alignment, and background image. Title and Text
accept Church Identity references such as `{CID.Name}`. Enter tokens explicitly;
empty fields remain empty. Draft Preview resolves the current Church Identity,
and Bake freezes the values for Guest playback. Image slides display
an image. Slides can be enabled or disabled and can override their duration.

The selected CRS Theme palette is captured during Bake. A Guest Service Plan
therefore retains the baked slide appearance without installing the Host's
custom Theme. Re-Bake to publish later edits. Music in Media Details preview
starts muted; the enlarged preview can enable it temporarily.

## Design notes

Loop Slides and Loop Audio are independent. Zero disables a fade or start delay.
Stop at End makes music end with the show; with Loop Slides enabled it restarts
at each cycle, applying Start Offset, delay and fade again. See MUSIC_CONTROLS.md.

In a Text slide's Markdown body, a Church Identity QR reference on its own
line appears as a QR image. Its size follows Markdown heading order:

| Markdown line | QR size |
| --- | --- |
| `{CID.QR.Giving.Online-giving}` | Small |
| `### {CID.QR.Giving.Online-giving}` | Medium |
| `## {CID.QR.Giving.Online-giving}` | Large |
| `# {CID.QR.Giving.Online-giving}` | Extra large |

Use a QR reference that exists in your Church Identity Saved Links. Keep it on
its own line; ordinary text references remain text. If a QR shares a line with
other text, Announcements does not render it as an image.

## Use

1. Import this ZIP into the Media Library and open its Media Details.
2. Add or edit slides. Use Draft Preview to inspect each slide.
3. Save, then Bake. Queue the baked HTML item for a service.
4. Test the service on your output before using it live.

The package includes no pre-filled church announcements or media. Provide your
own text, images, and optional music.

This package is designed for a 16:9 output. Resize the output window with
uniform scaling; any letterbox area belongs to CRS and should remain black.

## CRS Theme color mapping

| Visible area | CRS Theme color |
| --- | --- |
| Slide background and space around a fitted image | Background |
| Slide title and body text | Text Primary, with contrast fallback against Background |
| Title underline and highlighted Events row | Accent (Card Border fallback) |
| Events date badges | Accent Secondary (Accent fallback) |
| Empty-slide message | Text Secondary (Text Primary fallback), with contrast fallback against Background |

Global Theme and Slide Theme offer the same three HTML presets: Black and Gold,
Black and Blue, and Black and White. The default is Black and Gold.
Requires the CRS Accent Secondary patch for the separate CRS date-badge color.
The earlier theme-menu patch gives both menus the same HTML/CRS group headings. A slide Theme override uses the same mapping; Inherit uses Global Settings. Selected images retain their own colors. QR images keep a white background for scanning. Text has a fixed dark shadow for readability. Primary is resolved but currently has no visible color role in this layout. The black transition backdrop stays black.

## Events slides

Choose **Events** as a slide's Type, select a Theme, enter a Title, and fill in
the multiline **Date | Event** field. Each Events slide owns its own list.
Choose **Background Image** to place an image behind the events.
There is no separate Events section or shared list.

Enter up to 10 non-empty lines. Split date and description with the first `|`.
Start a line with `*` to highlight the whole row; the marker is not displayed.
Blank lines are ignored. Lines beyond the first 10 non-empty lines are not shown.
Dates remain plain text: `11th`, `11-14th`, `10/11-14`, or `Every Wednesday`.
There is no calendar parsing or automatic scheduling. A line without `|` is
displayed as an event description with an empty date. Additional `|` characters
remain in the event description. Multiple lines may be highlighted.

```text
10/11-14 | Dr. Russel Speaking
10/24 | Fall Harvest Dinner
*11/14 | Church Work Day
12/31 | New Year's Eve Prayer Service
```

Dates appear in rounded colored badges. Active rows have a rounded background
and bold text across both columns. Black and Blue matches the blue badge layout.

Events uses the same Slide Theme field as Text and Service Times.
Choose Use Global Theme to follow Global Settings, or select Black and Gold,
Black and Blue, Black and White, or a CRS Theme for this slide. CRS Themes are also available; Background and Text Primary set normal
colors, Accent sets the highlighted row, and Accent Secondary sets date badges.
Black or white text is chosen separately for each colored surface. If a theme
has no Accent Secondary, badges use Accent. Theme selections are captured by Bake for Guest playback.
The syntax reminder appears in the field label and placeholder. The package
format currently has no custom info-tooltip or static-note control.

Rows wrap and their font shrinks when needed to fit the output. Keep descriptions
brief and inspect Draft Preview before Bake. Event text accepts Church Identity
references and is rendered as plain text. The package includes no pre-filled
events. Re-Bake after edits.

## Service Times slides

Choose **Service Times**, select a Slide Theme (or inherit the main Theme), and
enter a Title. The title defaults to Service Times when left empty. The same
Underline control adds the theme-colored divider used by other slide types.

In **Service | Time**, lines without `|` become centered section headings.
Lines with `|` place the service name on the left and the time on the right:

```
Sunday
Bible Study | 9:45 AM
Morning Service | 10:45 AM
Evening Service | 7:00 PM
Wednesday
Evening Service | 7:00 PM
```

**Padding** fills the space between each service and time with blank space,
`.`, `•`, `✦`, or `-`. Blank lines are ignored. Text is plain text, and time
labels are freeform. Theme Text sets the row colors; Accent sets the section
headings and title divider. Choose **Background Image** to place an image behind the service list.
Keep the list short and preview it for readability.

## Theme contrast in 1.0.7

For CRS Themes, title/body and secondary text retain their supplied colors when
they reach a 4.5:1 contrast ratio against the Theme Background. Otherwise the
package chooses black or white, whichever contrasts more strongly. Date badges
and highlighted rows retain their existing independent contrast handling.
This does not change CRS palettes, HTML presets, controls, music or transitions.
Image backgrounds need a separate visual check: a solid-color contrast calculation
cannot guarantee readability over an image. Existing Baked scenes require an
explicit Re-Bake after updating the source package.

## Adaptive color in 1.0.12 (trial)

Requires the previously delivered Shared Image Contrast v2 and Adaptive Color
CRS patches. No additional CRS patch is required for this package update.

Enable Adaptive color on a Text slide with a Background Image. The visible image's
bright, colorful accents determine one shared hue for title, body and underline.
Local samples behind each element determine a readable shade of that hue.
Near-black shades are no longer accepted before considering more colorful shades.
Neutral images remain neutral. Mixed backgrounds may require a neutral fallback
and outline; approximate sampling does not guarantee readability over every pixel.

The existing cached 32 x 32 RGB map is reused. No canvas reads, network access,
new permissions or playback timers. Disable restores Theme styling. Missing
analysis retains Theme styling. Old brightness-only maps retain their fallback.
Music and transitions are unchanged. Existing baked scenes need explicit Re-Bake.

## Continuous Fold integration trial, 1.0.25

Page Turn now uses one frozen outgoing HTML copy, a continuous clipped front,
and a plain Theme-colored paper back with continuous shading. It replaces the
strip/triangle renderer. Text, local images, inline Adaptive Color and outgoing
Theme variables are preserved. No third-party code, capture APIs or new permissions.
The crease reaches the edge at completion, removing the prototype's invisible tail.

Select Page Turn and test 0.9, 1.0 and 1.1 seconds. Cut remains the default.
Music remains outside the transition. Per-slide randomized Bake shapes are deferred.
Resize or hiding finishes the turn. Closing/replacing it removes temporary layers.
Incoming images have a bounded three-second wait. The existing 125-descendant
content guard still falls back to Cut; only one outgoing clone is created.

Show transition diagnostics remains optional and off by default. It reports the
JavaScript clock, completion callback and layer cleanup, not delivered-frame
latency. A single label-only probe runs 250 ms after completion when enabled.
Disable diagnostics and explicitly Re-Bake before service use.

The standalone continuous-fold prototype was visually preferred by the user.
This package integration still needs Preview, Presentation and OBS verification.

## Fold edge refinement

Adds a narrow crease highlight and adjacent soft shadow on the existing paper
back. Motion, completion timing, layer count and audio behavior are unchanged.
The 1.0.22 recording was reported overall good; the edge needed more definition.
Visual acceptance of this 1.0.25 refinement remains open. Compare light and dark
slides at the same duration. Explicitly Re-Bake before checking live outputs.

## Theme-colored sharp edge

Only the narrow crease highlight now uses the outgoing slide Card Border color,
at the same opacity as before. Soft shading, paper color, geometry and timing
are unchanged. HTML presets use their highlight color because they have no
separate Card Border field. The color is captured before the incoming Theme is
applied. Import the inner ZIP and explicitly Re-Bake. Visual testing remains open.

## Folded paper shade, 1.0.25

The folded back mixes the outgoing page color 25% toward white for dark colors
and 25% toward black for light colors. The original page stays unchanged.
The theme-colored crease, soft shading and timing are retained. This is a
visual trial; compare the free corner on dark olive, black and cream pages.
Import the inner ZIP and explicitly Re-Bake for live output.

## Start Offset -- 1.0.27

See START_OFFSET.md. Start Offset skips the beginning of the audio file;
Delay Start waits before playing. These are independent controls.


## Music control notes

Choose Music to reveal its controls. Use the adjacent info buttons for short
explanations. Time fields accept whole seconds or mm:ss; fade fields accept
decimal seconds. Invalid time text keeps the last valid value until corrected.

- **Start Offset (mm:ss)**: Enter whole seconds or mm:ss. For example, 15 and 00:15 both skip fifteen seconds inside the song. This does not add a silent delay.
- **Fade In (seconds)**: Fade duration in seconds; 0 disables it. Begins when audio starts playing. Natural music repeats do not repeat the opening fade.
- **Start Delay (mm:ss)**: Enter whole seconds or mm:ss. Wait before starting at Start Offset. The delay is separate from the position inside the song.
- **Fade Out (seconds)**: Fade duration in seconds; 0 disables it. Applies only with Stop at End, and fits inside the final slide hold.
- **Stop at End**: Stop music after the final slide hold. Loop Slides restarts music, offset, delay and opening fade on each show cycle. Queue advancement remains manual.
- **Loop Audio**: Repeat the song independently of Loop Slides. Stop at End still ends the music with the show.

Save stores authoring settings. Explicitly Re-Bake to change live output.
Enlarged preview sound is enabled separately and uses its own remembered volume
and audio output. The main Preview stays silent.


## Editing preview

With a supporting CRS version, changing controls holds a silent, settled Draft
preview. Restart clears the editing selection and plays from the beginning with
the configured music timing. This changes only Details preview, not saved loop
settings or live output. Older CRS versions retain their previous preview behavior.


## Text and list alignment -- 1.0.31

Text Alignment positions both paragraphs and complete bullet/numbered-list blocks
Left, Center or Right. Individual list items remain left-aligned within the list
for readability. The slide title remains centered. Long lists wrap within the
body area. This update preserves settled editing previews and music behavior.


## Slideshow ending fade -- 1.0.32

With Stop at End enabled, Fade Out is scheduled against the remaining slideshow,
including slide holds and planned transitions. It is no longer shortened to the
final slide hold. A 30-second Cut show with a five-second Fade Out begins fading
at 00:25 and stops at 00:30, even if its final slide lasts only one second.

The fade may span several slides or a transition. If it is longer than the show,
it spans the available show duration. Stop at End off preserves continuous music.
Loop Slides restarts the sequence at the existing wrap point. Start Offset and
Start Delay keep their existing meaning. The boundary is the slideshow end,
not the audio file duration; an audio track that ends earlier can still end early.

The end estimate is refreshed after each actual transition completes. Image
readiness or rendering stalls can extend a show; an already-running fade keeps
its current gain and extends toward the revised end without jumping louder.
This is slideshow scheduling, not sample-accurate AV synchronization.

Import this update, verify package version 1.0.32, and Re-Bake existing scenes
to include the repair. Keep the same saved audio/slide settings for comparison.
