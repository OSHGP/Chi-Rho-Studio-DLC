# Announcements en-US, version 1.0.1

A Custom HTML package for creating announcement slides in Chi Rho Studio (CRS).
Install the ZIP through the CRS Media Library. To study or adapt the package,
unzip it and edit `crs-scene.json` and `index.html`.

Requires a CRS build with per-slide Theme support (introduced on the
`0.15.1jp` branch at commit `37b0715`).

## Controls

Global Settings include Transition (Cut, Fade through black, Crossfade),
Transition Duration (0.2 to 2.0 seconds for Fade and Crossfade), Default
Duration, Loop, optional Music, and Theme. Cut is immediate.

Add slides in Media Details. A slide can inherit the Global Theme or select an
HTML, Media Scene, or specific CRS Theme. Text slides support a title, optional
underline, Markdown body, alignment, and background image. Title and Text
accept Church Identity references such as `{CID.Name}`. Enter tokens explicitly;
empty fields remain empty. Draft Preview resolves the current Church Identity,
and Bake freezes the values for Guest playback. Image slides display
an image. Slides can be enabled or disabled and can override their duration.

The selected CRS Theme palette is captured during Bake. A Guest Service Plan
therefore retains the baked slide appearance without installing the Host's
custom Theme. Re-Bake to publish later edits. Music in Media Details preview
starts muted; the enlarged preview can enable it temporarily.

## Use

1. Import this ZIP into the Media Library and open its Media Details.
2. Add or edit slides. Use Draft Preview to inspect each slide.
3. Save, then Bake. Queue the baked HTML item for a service.
4. Test the service on your output before using it live.

The package includes no pre-filled church announcements or media. Provide your
own text, images, and optional music.

This package is designed for a 16:9 output. Resize the output window with
uniform scaling; any letterbox area belongs to CRS and should remain black.
