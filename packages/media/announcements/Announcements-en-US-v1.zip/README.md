# Announcements en-US, version 1.0.3

A Custom HTML package for creating announcement slides in Chi Rho Studio (CRS).
Install the ZIP through the CRS Media Library. To study or adapt the package,
unzip it and edit `crs-scene.json` and `index.html`.

Requires a CRS build with per-slide Theme support (introduced on the
`0.15.1jp` branch at commit `37b0715`).

## Controls

Global Settings include Transition (Cut, Fade through black, Crossfade),
Transition Duration (0.2 to 2.0 seconds for Fade and Crossfade), Default
Duration, Loop, optional Music, and Theme. Cut is immediate.

Add slides in Media Details. A slide can inherit the Global Theme or select an
HTML, Media Scene, or specific CRS Theme. Text slides support a title, optional
underline, Markdown body, alignment, and background image. Title and Text
accept Church Identity references such as `{CID.Name}`. Enter tokens explicitly;
empty fields remain empty. Draft Preview resolves the current Church Identity,
and Bake freezes the values for Guest playback. Image slides display
an image. Slides can be enabled or disabled and can override their duration.

The selected CRS Theme palette is captured during Bake. A Guest Service Plan
therefore retains the baked slide appearance without installing the Host's
custom Theme. Re-Bake to publish later edits. Music in Media Details preview
starts muted; the enlarged preview can enable it temporarily.

## Design notes

When **Loop** is off, Announcements holds the last slide. Music continues to
its natural end and does not repeat. Moving to another queued item stops the
Announcements audio. When Loop is on, both slides and music repeat. If music
ends before the slides, the remaining slides continue without sound.

In a Text slide's Markdown body, a Church Identity QR reference on its own
line appears as a QR image. Its size follows Markdown heading order:

| Markdown line | QR size |
| --- | --- |
| `{CID.QR.Giving.Online-giving}` | Small |
| `### {CID.QR.Giving.Online-giving}` | Medium |
| `## {CID.QR.Giving.Online-giving}` | Large |
| `# {CID.QR.Giving.Online-giving}` | Extra large |

Use a QR reference that exists in your Church Identity Saved Links. Keep it on
its own line; ordinary text references remain text. If a QR shares a line with
other text, Announcements does not render it as an image.

## Use

1. Import this ZIP into the Media Library and open its Media Details.
2. Add or edit slides. Use Draft Preview to inspect each slide.
3. Save, then Bake. Queue the baked HTML item for a service.
4. Test the service on your output before using it live.

The package includes no pre-filled church announcements or media. Provide your
own text, images, and optional music.

This package is designed for a 16:9 output. Resize the output window with
uniform scaling; any letterbox area belongs to CRS and should remain black.

## CRS Theme color mapping

| Visible area | CRS Theme color |
| --- | --- |
| Slide background and space around a fitted image | Background |
| Slide title and body text | Text Primary |
| Title underline | Accent (Card Border fallback) |
| Empty-slide message | Text Secondary (Text Primary fallback) |

HTML Default uses the package-owned palette. A slide Theme override uses the same mapping; Inherit uses Global Settings. Selected images retain their own colors. QR images keep a white background for scanning. Text has a fixed dark shadow for readability. Primary is resolved but currently has no visible color role in this layout. The black transition backdrop stays black.
