/* CRS-supplied image analysis. No canvas reads, fetches or resource permissions. */
(function(root) {
  'use strict';
  function luminance(rgb) {
    const c=rgb.map(v=>{v/=255;return v<=.04045?v/12.92:((v+.055)/1.055)**2.4;});
    return .2126*c[0]+.7152*c[1]+.0722*c[2];
  }
  function contrast(a,b) {return (Math.max(a,b)+.05)/(Math.min(a,b)+.05);}
  function rgb(color) {
    const hex=/^#([0-9a-f]{6})$/i.exec(String(color).trim());
    if(hex)return [0,2,4].map(i=>parseInt(hex[1].slice(i,i+2),16));
    const m=/^rgba?\(\s*(\d+(?:\.\d+)?)[, ]+\s*(\d+(?:\.\d+)?)[, ]+\s*(\d+(?:\.\d+)?)(?:\s*[,/]\s*1(?:\.0+)?)?\s*\)$/i.exec(String(color).trim());
    return m?m.slice(1,4).map(Number):null;
  }
  function chooseInk(samples,preferred) {
    function score(c){const l=luminance(c),s=samples.map(v=>contrast(l,v)).sort((a,b)=>a-b);return s[Math.floor((s.length-1)*.1)];}
    const original=rgb(preferred);
    if(original&&score(original)>=4.5)return {color:preferred,outline:false};
    const white=score([255,255,255]),black=score([0,0,0]);
    return {color:white>black?'#ffffff':'#000000',outline:Math.max(white,black)<4.5};
  }
  function hsv(c) {
    const [r,g,b]=c.map(v=>v/255),v=Math.max(r,g,b),d=v-Math.min(r,g,b);
    let h=0;
    if(d)h=(v===r?(g-b)/d+(g<b?6:0):v===g?(b-r)/d+2:(r-g)/d+4)*60;
    return [h,v?d/v:0,v];
  }
  function fromHsv(h,s,v) {
    h=((h%360)+360)%360/60;
    const c=v*s,x=c*(1-Math.abs(h%2-1)),m=v-c;
    const a=h<1?[c,x,0]:h<2?[x,c,0]:h<3?[0,c,x]:h<4?[0,x,c]:h<5?[x,0,c]:[c,0,x];
    return a.map(n=>Math.round((n+m)*255));
  }
  // Bright, chromatic accents contribute more than nearly black or neutral areas.
  // Hue bins prevent complementary colors from averaging into muddy gray.
  function imagePalette(colors) {
    const bins=Array.from({length:24},()=>({weight:0,rgb:[0,0,0]}));
    for(const c of colors){
      const [h,s,v]=hsv(c),weight=s*v*v;
      if(s<.08||v<.08)continue;
      const bin=bins[Math.floor(h/15)%24];bin.weight+=weight;
      c.forEach((n,k)=>bin.rgb[k]+=n*weight);
    }
    const best=bins.reduce((a,b)=>b.weight>a.weight?b:a);
    if(!best.weight)return [0,0];
    const [h,s]=hsv(best.rgb.map(n=>n/best.weight));
    return [h,Math.min(.85,s)];
  }
  function adaptiveInk(colors,palette=imagePalette(colors)) {
    const [h,s]=palette,samples=colors.map(luminance);
    const allowance=Math.floor((samples.length-1)*.1);
    // Search both light and dark shades. Keep the greatest RGB chroma that
    // meets the same lower-tenth-percentile contrast target as the prior trial.
    let chosen=null,bestChroma=-1;
    for(let si=0;si<=16;si++)for(let vi=0;vi<=64;vi++){
      const c=fromHsv(h,s*si/16,vi/64),l=luminance(c);
      let failures=0;
      for(const y of samples){if(contrast(l,y)<4.5&&++failures>allowance)break;}
      if(failures>allowance)continue;
      const chroma=Math.max(...c)-Math.min(...c);
      if(chroma>bestChroma){chosen=c;bestChroma=chroma;}
    }
    // Mixed light/dark regions may have no passing single ink. Use the stronger
    // neutral plus the existing outline, without claiming guaranteed contrast.
    if(!chosen)return {...chooseInk(samples,'invalid'),outline:true};
    return {color:'#'+chosen.map(c=>c.toString(16).padStart(2,'0')).join(''),outline:true};
  }
  function complementaryPalette(palette,ink) {
    let [h,s]=palette||[0,0];
    const color=rgb(ink);
    if(color){
      const actual=hsv(color);
      // Near-neutral ink has no useful hue. Retain the image palette's hue
      // as the reference rather than pretending black/white has a complement.
      if(actual[1]>=.08&&actual[2]>=.08){h=actual[0];s=actual[1];}
    }
    return [((h+180)%360+360)%360,s];
  }
  function validMap(m) {
    return m&&m.version===1&&Number.isInteger(m.width)&&m.width>0&&Number.isInteger(m.height)&&m.height>0
      &&m.width*m.height<=67108864&&m.columns===32&&m.rows===32
      &&typeof m.checksum_sha256==='string'&&/^[0-9a-f]{64}$/.test(m.checksum_sha256)
      &&typeof m.luma==='string'&&/^[0-9a-f]{2048}$/.test(m.luma)
      &&(m.rgb===undefined||(typeof m.rgb==='string'&&/^[0-9a-f]{6144}$/.test(m.rgb)))
      &&typeof m.alpha==='string'&&/^[0-9a-f]{2048}$/.test(m.alpha);
  }
  function coverGeometry(nw,nh,box) {
    const scale=Math.max(box.width/nw,box.height/nh);
    return {x:box.left+(box.width-nw*scale)/2,y:box.top+(box.height-nh*scale)/2,width:nw*scale,height:nh*scale};
  }
  function sampleMap(map,box,rects,background,colorBackground=null) {
    if(!validMap(map)||box.width<=0||box.height<=0||!Number.isFinite(background))return [];
    const geo=coverGeometry(map.width,map.height,box),indices=new Set();
    const count=Math.min(16,rects.length);
    for(let n=0;n<count;n++) {
      const r=rects[Math.floor(n*rects.length/count)];
      const left=Math.max(box.left,r.left),right=Math.min(box.right,r.right);
      const top=Math.max(box.top,r.top),bottom=Math.min(box.bottom,r.bottom);
      if(right<=left||bottom<=top)continue;
      const x0=Math.max(0,Math.floor((left-geo.x)/geo.width*32)),x1=Math.min(32,Math.ceil((right-geo.x)/geo.width*32));
      const y0=Math.max(0,Math.floor((top-geo.y)/geo.height*32)),y1=Math.min(32,Math.ceil((bottom-geo.y)/geo.height*32));
      for(let y=y0;y<y1;y++)for(let x=x0;x<x1;x++)indices.add(y*32+x);
    }
    return [...indices].map(i=>{
      const alpha=parseInt(map.alpha.slice(i*2,i*2+2),16)/255;
      if(colorBackground&&map.rgb)return [0,1,2].map(k=>parseInt(map.rgb.slice(i*6+k*2,i*6+k*2+2),16)*alpha+colorBackground[k]*(1-alpha));
      return parseInt(map.luma.slice(i*2,i*2+2),16)/255*alpha+background*(1-alpha);
    });
  }
  function create(image,targets,stage,accent=null) {
    let enabled=false,map=null,frame=0,disposed=false,preferred=[];
    const accentSaved=accent?{background:accent.style.backgroundColor,shadow:accent.style.boxShadow}:null;
    const saved=targets.map(el=>({color:el.style.color,shadow:el.style.textShadow}));
    function restore(){if(accent){accent.style.backgroundColor=accentSaved.background;accent.style.boxShadow=accentSaved.shadow;}targets.forEach((el,i)=>{el.style.color=saved[i].color;el.style.textShadow=saved[i].shadow;});}
    function textBounds(el) {
      const walker=document.createTreeWalker(el,NodeFilter.SHOW_TEXT),rects=[];
      let node,visited=0;
      while((node=walker.nextNode())&&visited++<512){
        if(!node.textContent.trim())continue;
        const range=document.createRange();range.selectNodeContents(node);
        for(const r of range.getClientRects()){if(r.width>0&&r.height>0)rects.push(r);if(rects.length>=256)break;}
        if(rects.length>=256)break;
      }
      return rects;
    }
    function analyze(){
      frame=0;
      if(!enabled||disposed||document.hidden)return;
      restore();
      if(!validMap(map)||!image.complete||!image.naturalWidth||!image.classList.contains('visible'))return;
      const color=rgb(getComputedStyle(stage).getPropertyValue('--page').trim());
      if(!color)return;
      const background=luminance(color),box=image.getBoundingClientRect();
      const palette=map.rgb?imagePalette(sampleMap(map,box,[box],background,color)):null;
      let firstTextInk=null;
      targets.forEach((el,i)=>{
        const samples=sampleMap(map,box,textBounds(el),background,map.rgb?color:null);
        if(!samples.length)return;
        const ink=map.rgb?adaptiveInk(samples,palette):chooseInk(samples,preferred[i]),edge=luminance(rgb(ink.color))<.179?'#fff':'#000';
        if(firstTextInk===null)firstTextInk=ink.color;
        ink.outline=true;
        el.style.color=ink.color;
        el.style.textShadow=ink.outline?`1px 0 1px ${edge}, -1px 0 1px ${edge}, 0 1px 1px ${edge}, 0 -1px 1px ${edge}`:saved[i].shadow;
      });
      if(accent&&getComputedStyle(accent).display!=='none'){
        const samples=sampleMap(map,box,[accent.getBoundingClientRect()],background,map.rgb?color:null);
        if(samples.length){
          const ink=map.rgb?adaptiveInk(samples,complementaryPalette(palette,firstTextInk)):chooseInk(samples,getComputedStyle(accent).backgroundColor);
          const edge=luminance(rgb(ink.color))<.179?'#fff':'#000';
          accent.style.backgroundColor=ink.color;accent.style.boxShadow=`0 0 0 1px ${edge}`;
        }
      }
    }
    function schedule(){if(enabled&&!disposed&&!document.hidden&&!frame)frame=requestAnimationFrame(analyze);}
    function cancel(){if(frame)cancelAnimationFrame(frame);frame=0;}
    function configure(value,data){cancel();restore();enabled=value===true;map=validMap(data)?data:null;preferred=targets.map(el=>getComputedStyle(el).color);if(enabled)analyze();}
    function visibility(){if(document.hidden)cancel();else schedule();}
    image.addEventListener('load',schedule);image.addEventListener('error',schedule);
    window.addEventListener('resize',schedule);document.addEventListener('visibilitychange',visibility);
    const observer=typeof ResizeObserver==='function'?new ResizeObserver(schedule):null;
    targets.forEach(el=>observer?.observe(el));document.fonts?.addEventListener('loadingdone',schedule);
    function dispose(){disposed=true;enabled=false;cancel();restore();observer?.disconnect();image.removeEventListener('load',schedule);image.removeEventListener('error',schedule);window.removeEventListener('resize',schedule);document.removeEventListener('visibilitychange',visibility);document.fonts?.removeEventListener('loadingdone',schedule);}
    return {configure,dispose};
  }
  root.CrsAutoTextColor={create,chooseInk,adaptiveInk,imagePalette,complementaryPalette,hsv,fromHsv,coverGeometry,luminance,contrast,validMap,sampleMap};
})(typeof window==='undefined'?globalThis:window);
